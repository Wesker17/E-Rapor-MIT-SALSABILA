<?php
// =============================================
// KONFIGURASI DATABASE - E-RAPOR SD MIT SALSABILA
// =============================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'erapor_salsabila');
define('DB_CHARSET', 'utf8mb4');

define('APP_NAME', 'E-Rapor SD MIT Salsabila');
define('APP_URL', 'http://localhost/erapor');
define('TAHUN_AJARAN', '2024/2025');
define('SEMESTER', 1);

function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die('<div style="font-family:sans-serif;color:red;padding:20px;">
                <h2>❌ Koneksi Database Gagal</h2>
                <p>' . htmlspecialchars($e->getMessage()) . '</p>
                <p>Pastikan MySQL berjalan dan database <strong>' . DB_NAME . '</strong> sudah dibuat.</p>
            </div>');
        }
    }
    return $pdo;
}
