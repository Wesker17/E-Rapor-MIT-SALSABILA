# E-Rapor SD MIT Salsabila
Sistem Informasi Rapor Digital berbasis PHP + MySQL dengan tema hijau islami.

---

## 📋 Fitur Utama

| Role | Akses |
|---|---|
| **Admin** | CRUD pengguna, kelas, siswa, mapel, penugasan guru, relasi ortu-siswa, laporan rekap |
| **Guru** | Input & lihat nilai hanya untuk mapel yang dia ajar |
| **Wali Kelas** | Lihat siswa kelas, rekap nilai, kehadiran, cetak rapor |
| **Orang Tua** | Lihat nilai & rapor anak kandungnya saja |

---

## ⚙️ Persyaratan Server

- PHP 8.0 atau lebih baru (dengan ekstensi PDO, PDO_MySQL)
- MySQL 5.7 / MariaDB 10.3 atau lebih baru
- Apache dengan `mod_rewrite` aktif
- Web server lokal: **XAMPP / WAMP / Laragon** (direkomendasikan)

---

## 🚀 Langkah Instalasi

### 1. Salin Folder Proyek
Salin seluruh folder `erapor` ke direktori web server:
- **XAMPP**: `C:/xampp/htdocs/erapor`
- **WAMP**: `C:/wamp64/www/erapor`
- **Laragon**: `C:/laragon/www/erapor`

### 2. Buat Database
Buka **phpMyAdmin** (http://localhost/phpmyadmin) lalu:
1. Klik **New** → beri nama database: `erapor_salsabila`
2. Klik tab **Import** → pilih file `database.sql`
3. Klik **Go / Impor**

### 3. Konfigurasi Koneksi Database
Edit file `config/database.php`:
```php
define('DB_HOST', 'localhost');   // host database
define('DB_USER', 'root');        // username MySQL
define('DB_PASS', '');            // password MySQL (kosong di XAMPP default)
define('DB_NAME', 'erapor_salsabila');

define('APP_URL', 'http://localhost/erapor');  // sesuaikan path
define('TAHUN_AJARAN', '2024/2025');           // tahun ajaran aktif
define('SEMESTER', 1);                          // semester aktif (1 atau 2)
```

### 4. Akses Aplikasi
Buka browser: **http://localhost/erapor**

---

## 🔑 Akun Login Demo

| Username | Password | Role |
|---|---|---|
| `admin` | `password` | Administrator |
| `guru1` | `password` | Guru (PAI, BAR) |
| `guru2` | `password` | Guru (MTK, IPA) |
| `guru3` | `password` | Guru (BIN, IPS) |
| `wk1` | `password` | Wali Kelas 1A |
| `wk2` | `password` | Wali Kelas 2A |
| `ortu1` | `password` | Orang Tua (Kelas 1A) |
| `ortu2` | `password` | Orang Tua (Kelas 2A) |

---

## 📁 Struktur Folder

```
erapor/
├── index.php              # Halaman login
├── logout.php
├── dashboard.php          # Dashboard (adaptif per role)
├── database.sql           # File SQL database
├── .htaccess
├── config/
│   └── database.php       # Konfigurasi DB & konstanta
├── includes/
│   ├── auth.php           # Fungsi autentikasi & helper
│   ├── header.php         # Template header + sidebar
│   └── footer.php         # Template footer
├── assets/
│   └── css/
│       └── style.css      # Stylesheet utama (tema hijau)
└── pages/
    ├── profil.php         # Profil pengguna (semua role)
    ├── admin/
    │   ├── users.php      # CRUD pengguna
    │   ├── kelas.php      # CRUD kelas
    │   ├── siswa.php      # CRUD siswa
    │   ├── mapel.php      # CRUD mata pelajaran
    │   ├── guru_mapel.php # Penugasan guru-mapel-kelas
    │   ├── ortu_siswa.php # Relasi orang tua - siswa
    │   └── laporan.php    # Rekap nilai per kelas
    ├── guru/
    │   ├── input_nilai.php  # Input nilai siswa
    │   └── lihat_nilai.php  # Lihat nilai yang sudah diinput
    ├── walikelas/
    │   ├── siswa_kelas.php  # Daftar siswa kelas
    │   ├── rekap_nilai.php  # Rekap nilai lengkap
    │   ├── kehadiran.php    # Input kehadiran siswa
    │   └── rapor.php        # Preview & cetak rapor
    └── ortu/
        ├── nilai_anak.php   # Lihat nilai anak
        └── rapor_anak.php   # Lihat & cetak rapor anak
```

---

## 🎨 Rumus Penilaian

```
Nilai Akhir = (Nilai Harian × 40%) + (UTS × 30%) + (UAS × 30%)
```

| Predikat | Rentang |
|---|---|
| A+ | ≥ 93 |
| A  | ≥ 85 |
| A- | ≥ 80 |
| B+ | ≥ 75 |
| B  | ≥ 70 |
| B- | ≥ 65 |
| C+ | ≥ 60 |
| C  | ≥ 55 |
| C- | ≥ 50 |
| D  | < 50  |

---

## 🔒 Keamanan

- Password di-hash menggunakan `password_hash()` (bcrypt)
- Prepared statement PDO untuk mencegah SQL Injection
- Role-based access control (RBAC) pada setiap halaman
- Guru hanya bisa input nilai sesuai penugasannya
- Orang tua hanya bisa melihat data anak yang terhubung

---

## 🖨️ Cetak Rapor

Rapor dapat dicetak langsung dari browser (Ctrl+P) atau disimpan sebagai PDF menggunakan fitur "Print to PDF" pada browser Chrome/Edge.

---

*© 2024 SD MIT Salsabila — Sistem E-Rapor Digital*
