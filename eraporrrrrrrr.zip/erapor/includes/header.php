<?php
// Header template
$user = getCurrentUser();
$flashes = getFlashMessages();
$pageTitle = $pageTitle ?? APP_NAME;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?> - <?= APP_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Amiri:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-brand">
        <div class="brand-logo">
            <i class="fas fa-graduation-cap"></i>
        </div>
        <div class="brand-text">
            <span class="brand-name">MIT Salsabila</span>
            <span class="brand-sub">E-Rapor Digital</span>
        </div>
    </div>

    <div class="sidebar-user">
        <div class="user-avatar">
            <?= strtoupper(substr($user['nama_lengkap'], 0, 1)) ?>
        </div>
        <div class="user-info">
            <span class="user-name"><?= htmlspecialchars($user['nama_lengkap']) ?></span>
            <span class="user-role badge-role-<?= $user['role'] ?>"><?= ucfirst($user['role'] === 'ortu' ? 'Orang Tua' : ($user['role'] === 'walikelas' ? 'Wali Kelas' : ucfirst($user['role']))) ?></span>
        </div>
    </div>

    <nav class="sidebar-nav">
        <?php if ($user['role'] === 'admin'): ?>
        <div class="nav-section">MENU UTAMA</div>
        <a href="<?= APP_URL ?>/dashboard.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>">
            <i class="fas fa-home"></i> <span>Dashboard</span>
        </a>
        <div class="nav-section">MANAJEMEN</div>
        <a href="<?= APP_URL ?>/pages/admin/users.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : '' ?>">
            <i class="fas fa-users"></i> <span>Data Pengguna</span>
        </a>
        <a href="<?= APP_URL ?>/pages/admin/kelas.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'kelas.php' ? 'active' : '' ?>">
            <i class="fas fa-chalkboard"></i> <span>Data Kelas</span>
        </a>
        <a href="<?= APP_URL ?>/pages/admin/siswa.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'siswa.php' ? 'active' : '' ?>">
            <i class="fas fa-user-graduate"></i> <span>Data Siswa</span>
        </a>
        <a href="<?= APP_URL ?>/pages/admin/mapel.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'mapel.php' ? 'active' : '' ?>">
            <i class="fas fa-book"></i> <span>Mata Pelajaran</span>
        </a>
        <a href="<?= APP_URL ?>/pages/admin/guru_mapel.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'guru_mapel.php' ? 'active' : '' ?>">
            <i class="fas fa-link"></i> <span>Penugasan Guru</span>
        </a>
        <a href="<?= APP_URL ?>/pages/admin/ortu_siswa.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'ortu_siswa.php' ? 'active' : '' ?>">
            <i class="fas fa-people-arrows"></i> <span>Relasi Ortu-Siswa</span>
        </a>
        <div class="nav-section">LAPORAN</div>
        <a href="<?= APP_URL ?>/pages/admin/laporan.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'laporan.php' ? 'active' : '' ?>">
            <i class="fas fa-chart-bar"></i> <span>Rekap Nilai</span>
        </a>

        <?php elseif ($user['role'] === 'guru'): ?>
        <div class="nav-section">MENU UTAMA</div>
        <a href="<?= APP_URL ?>/dashboard.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>">
            <i class="fas fa-home"></i> <span>Dashboard</span>
        </a>
        <div class="nav-section">INPUT NILAI</div>
        <a href="<?= APP_URL ?>/pages/guru/input_nilai.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'input_nilai.php' ? 'active' : '' ?>">
            <i class="fas fa-pen-to-square"></i> <span>Input Nilai</span>
        </a>
        <a href="<?= APP_URL ?>/pages/guru/lihat_nilai.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'lihat_nilai.php' ? 'active' : '' ?>">
            <i class="fas fa-table-list"></i> <span>Lihat Nilai</span>
        </a>

        <?php elseif ($user['role'] === 'walikelas'): ?>
        <div class="nav-section">MENU UTAMA</div>
        <a href="<?= APP_URL ?>/dashboard.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>">
            <i class="fas fa-home"></i> <span>Dashboard</span>
        </a>
        <div class="nav-section">KELAS SAYA</div>
        <a href="<?= APP_URL ?>/pages/walikelas/siswa_kelas.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'siswa_kelas.php' ? 'active' : '' ?>">
            <i class="fas fa-user-group"></i> <span>Siswa Kelas</span>
        </a>
        <a href="<?= APP_URL ?>/pages/walikelas/rekap_nilai.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'rekap_nilai.php' ? 'active' : '' ?>">
            <i class="fas fa-table"></i> <span>Rekap Nilai</span>
        </a>
        <a href="<?= APP_URL ?>/pages/walikelas/kehadiran.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'kehadiran.php' ? 'active' : '' ?>">
            <i class="fas fa-calendar-check"></i> <span>Kehadiran</span>
        </a>
        <a href="<?= APP_URL ?>/pages/walikelas/rapor.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'rapor.php' ? 'active' : '' ?>">
            <i class="fas fa-file-alt"></i> <span>Cetak Rapor</span>
        </a>

        <?php elseif ($user['role'] === 'ortu'): ?>
        <div class="nav-section">MENU UTAMA</div>
        <a href="<?= APP_URL ?>/dashboard.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>">
            <i class="fas fa-home"></i> <span>Dashboard</span>
        </a>
        <div class="nav-section">DATA ANAK</div>
        <a href="<?= APP_URL ?>/pages/ortu/nilai_anak.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'nilai_anak.php' ? 'active' : '' ?>">
            <i class="fas fa-star"></i> <span>Nilai Anak</span>
        </a>
        <a href="<?= APP_URL ?>/pages/ortu/rapor_anak.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'rapor_anak.php' ? 'active' : '' ?>">
            <i class="fas fa-file-pdf"></i> <span>Lihat Rapor</span>
        </a>
        <?php endif; ?>

        <div class="nav-section">AKUN</div>
        <a href="<?= APP_URL ?>/pages/profil.php" class="nav-item <?= basename($_SERVER['PHP_SELF']) == 'profil.php' ? 'active' : '' ?>">
            <i class="fas fa-user-cog"></i> <span>Profil Saya</span>
        </a>
        <a href="<?= APP_URL ?>/logout.php" class="nav-item nav-logout">
            <i class="fas fa-sign-out-alt"></i> <span>Keluar</span>
        </a>
    </nav>
</div>

<!-- Main Content -->
<div class="main-wrapper">
    <!-- Topbar -->
    <div class="topbar">
        <button class="sidebar-toggle" onclick="toggleSidebar()">
            <i class="fas fa-bars"></i>
        </button>
        <div class="topbar-title"><?= htmlspecialchars($pageTitle) ?></div>
        <div class="topbar-right">
            <div class="tahun-badge">
                <i class="fas fa-calendar"></i>
                TA <?= TAHUN_AJARAN ?> &nbsp;|&nbsp; Semester <?= SEMESTER ?>
            </div>
        </div>
    </div>

    <!-- Flash Messages -->
    <?php foreach ($flashes as $type => $message): ?>
    <div class="alert alert-<?= $type ?>">
        <i class="fas fa-<?= $type === 'success' ? 'check-circle' : ($type === 'error' ? 'times-circle' : 'info-circle') ?>"></i>
        <?= htmlspecialchars($message) ?>
        <button onclick="this.parentElement.remove()" class="alert-close">&times;</button>
    </div>
    <?php endforeach; ?>

    <div class="content-area">
