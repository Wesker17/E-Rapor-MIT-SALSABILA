<?php
/**
 * XlsxReader
 * Pembaca file .xlsx sederhana tanpa dependency (murni PHP + ext-zip + ext-simplexml).
 * Cukup untuk kebutuhan import data siswa dari Excel (satu sheet, data tabular).
 */
class XlsxReader
{
    /**
     * Membaca sheet pertama dari file .xlsx dan mengembalikan array baris.
     * Setiap baris adalah array nilai (index 0,1,2,... sesuai kolom A,B,C,...).
     *
     * @param string $path path file .xlsx di server
     * @return array
     * @throws Exception
     */
    public static function read($path)
    {
        if (!class_exists('ZipArchive')) {
            throw new Exception('Ekstensi PHP "zip" tidak aktif di server. Hubungi administrator hosting.');
        }

        $zip = new ZipArchive();
        if ($zip->open($path) !== true) {
            throw new Exception('File .xlsx tidak valid atau rusak.');
        }

        // 1. Baca shared strings (teks di Excel biasanya disimpan terpisah dari sheet)
        $sharedStrings = [];
        $ssData = $zip->getFromName('xl/sharedStrings.xml');
        if ($ssData !== false) {
            $ssXml = @simplexml_load_string($ssData);
            if ($ssXml !== false) {
                foreach ($ssXml->si as $si) {
                    if (isset($si->t)) {
                        $sharedStrings[] = (string)$si->t;
                    } else {
                        $text = '';
                        foreach ($si->r as $r) {
                            $text .= (string)$r->t;
                        }
                        $sharedStrings[] = $text;
                    }
                }
            }
        }

        // 2. Tentukan sheet pertama yang sebenarnya lewat workbook.xml + relationships
        $sheetPath = self::resolveFirstSheetPath($zip);

        $sheetData = $zip->getFromName($sheetPath);
        if ($sheetData === false) {
            // fallback: coba nama umum sheet1.xml..sheet5.xml
            for ($i = 1; $i <= 5; $i++) {
                $sheetData = $zip->getFromName("xl/worksheets/sheet{$i}.xml");
                if ($sheetData !== false) break;
            }
        }

        if ($sheetData === false) {
            $zip->close();
            throw new Exception('Data sheet tidak ditemukan di dalam file .xlsx.');
        }

        $xml = @simplexml_load_string($sheetData);
        $zip->close();

        if ($xml === false || !isset($xml->sheetData)) {
            throw new Exception('Gagal membaca isi sheet Excel.');
        }

        $rows = [];
        foreach ($xml->sheetData->row as $rowXml) {
            $rowIndex = ((int)$rowXml['r']) - 1;
            if ($rowIndex < 0) $rowIndex = count($rows);

            $rowArr = [];
            foreach ($rowXml->c as $c) {
                $ref = (string)$c['r'];
                preg_match('/([A-Z]+)(\d+)/', $ref, $m);
                $colLetters = $m[1] ?? '';
                $colIndex = $colLetters !== '' ? self::colLettersToIndex($colLetters) : count($rowArr);

                $type = (string)$c['t'];
                $value = '';
                if ($type === 's') {
                    $vIdx = isset($c->v) ? (int)$c->v : -1;
                    $value = $sharedStrings[$vIdx] ?? '';
                } elseif ($type === 'inlineStr') {
                    $value = isset($c->is->t) ? (string)$c->is->t : '';
                } else {
                    // str (formula result), number, date serial, boolean, dsb
                    $value = isset($c->v) ? (string)$c->v : '';
                }
                $rowArr[$colIndex] = $value;
            }

            if (!empty($rowArr)) {
                $maxCol = max(array_keys($rowArr));
                $ordered = [];
                for ($i = 0; $i <= $maxCol; $i++) {
                    $ordered[$i] = $rowArr[$i] ?? '';
                }
                $rows[$rowIndex] = $ordered;
            }
        }

        ksort($rows);
        return array_values($rows);
    }

    private static function resolveFirstSheetPath(ZipArchive $zip)
    {
        $default = 'xl/worksheets/sheet1.xml';

        $wbData = $zip->getFromName('xl/workbook.xml');
        $relsData = $zip->getFromName('xl/_rels/workbook.xml.rels');
        if ($wbData === false || $relsData === false) {
            return $default;
        }

        $wbXml = @simplexml_load_string($wbData);
        $relsXml = @simplexml_load_string($relsData);
        if ($wbXml === false || $relsXml === false || !isset($wbXml->sheets->sheet[0])) {
            return $default;
        }

        $relMap = [];
        foreach ($relsXml->Relationship as $rel) {
            $relMap[(string)$rel['Id']] = (string)$rel['Target'];
        }

        $rNs = $wbXml->sheets->sheet[0]->attributes('http://schemas.openxmlformats.org/officeDocument/2006/relationships');
        $rId = isset($rNs['id']) ? (string)$rNs['id'] : '';

        if ($rId !== '' && isset($relMap[$rId])) {
            $target = ltrim($relMap[$rId], '/');
            if (strpos($target, 'xl/') !== 0) {
                $target = 'xl/' . $target;
            }
            return $target;
        }

        return $default;
    }

    private static function colLettersToIndex($letters)
    {
        $letters = strtoupper($letters);
        $index = 0;
        for ($i = 0; $i < strlen($letters); $i++) {
            $index = $index * 26 + (ord($letters[$i]) - ord('A') + 1);
        }
        return $index - 1;
    }
}
