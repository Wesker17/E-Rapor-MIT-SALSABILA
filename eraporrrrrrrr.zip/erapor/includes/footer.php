    </div><!-- end content-area -->
</div><!-- end main-wrapper -->

<script>
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('collapsed');
    document.querySelector('.main-wrapper').classList.toggle('expanded');
}

// Auto-close alerts
document.querySelectorAll('.alert').forEach(el => {
    setTimeout(() => { el.style.opacity='0'; setTimeout(() => el.remove(), 400); }, 5000);
});

// Confirm delete
function confirmDelete(url, name) {
    if (confirm('Apakah Anda yakin ingin menghapus "' + name + '"?')) {
        window.location.href = url;
    }
}
</script>
<footer class="app-footer">
    <p>&copy; <?= date('Y') ?> <?= APP_NAME ?> &mdash; Sistem Informasi Rapor Digital</p>
</footer>
</body>
</html>
