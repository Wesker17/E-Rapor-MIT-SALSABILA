<?php
// =============================================
// HELPER FUNCTIONS - AUTH & SESSION
// =============================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . APP_URL . '/index.php');
        exit;
    }
}

function requireRole($roles) {
    requireLogin();
    if (!is_array($roles)) $roles = [$roles];
    if (!in_array($_SESSION['role'], $roles)) {
        header('Location: ' . APP_URL . '/dashboard.php');
        exit;
    }
}

function getCurrentUser() {
    if (!isLoggedIn()) return null;
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch();
}

function login($username, $password) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ? AND aktif = 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id']     = $user['id'];
        $_SESSION['username']    = $user['username'];
        $_SESSION['nama']        = $user['nama_lengkap'];
        $_SESSION['role']        = $user['role'];
        return true;
    }
    return false;
}

function logout() {
    session_destroy();
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

function getPredikat($nilai) {
    if ($nilai >= 93) return 'A+';
    if ($nilai >= 85) return 'A';
    if ($nilai >= 80) return 'A-';
    if ($nilai >= 75) return 'B+';
    if ($nilai >= 70) return 'B';
    if ($nilai >= 65) return 'B-';
    if ($nilai >= 60) return 'C+';
    if ($nilai >= 55) return 'C';
    if ($nilai >= 50) return 'C-';
    return 'D';
}

function hitungNilaiAkhir($harian, $uts, $uas) {
    return round(($harian * 0.4) + ($uts * 0.3) + ($uas * 0.3), 2);
}

function formatNilai($nilai) {
    return number_format($nilai, 1);
}

function getKelasWalikelas($walikelas_id) {
    $db = getDB();
    // Prioritaskan kelas dengan tahun ajaran aktif, fallback ke semua kelas yang ditugaskan
    $stmt = $db->prepare("SELECT * FROM kelas WHERE walikelas_id = ? AND tahun_ajaran = ? ORDER BY tingkat");
    $stmt->execute([$walikelas_id, TAHUN_AJARAN]);
    $result = $stmt->fetchAll();
    if (!empty($result)) return $result;

    // Fallback: ambil kelas yang ditugaskan meski tahun ajaran berbeda
    $stmt2 = $db->prepare("SELECT * FROM kelas WHERE walikelas_id = ? ORDER BY tahun_ajaran DESC, tingkat");
    $stmt2->execute([$walikelas_id]);
    return $stmt2->fetchAll();
}

function flash($key, $message = null) {
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
    } else {
        $msg = $_SESSION['flash'][$key] ?? null;
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
}

function getFlashMessages() {
    $flashes = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $flashes;
}
