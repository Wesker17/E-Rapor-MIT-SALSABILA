<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('admin');
$db = getDB();
$pageTitle = 'Manajemen Kelas';

$action = $_GET['action'] ?? '';
$id     = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_kelas   = trim($_POST['nama_kelas']);
    $tingkat      = (int)$_POST['tingkat'];
    $tahun_ajaran = $_POST['tahun_ajaran'];
    $walikelas_id = $_POST['walikelas_id'] ?: null;

    if ($action === 'tambah') {
        $db->prepare("INSERT INTO kelas (nama_kelas,tingkat,tahun_ajaran,walikelas_id) VALUES (?,?,?,?)")
           ->execute([$nama_kelas,$tingkat,$tahun_ajaran,$walikelas_id]);
        flash('success','Kelas berhasil ditambahkan!');
    } elseif ($action === 'edit' && $id) {
        $db->prepare("UPDATE kelas SET nama_kelas=?,tingkat=?,tahun_ajaran=?,walikelas_id=? WHERE id=?")
           ->execute([$nama_kelas,$tingkat,$tahun_ajaran,$walikelas_id,$id]);
        flash('success','Kelas berhasil diperbarui!');
    }
    header('Location: kelas.php'); exit;
}

if ($action === 'hapus' && $id) {
    $db->prepare("DELETE FROM kelas WHERE id=?")->execute([$id]);
    flash('success','Kelas berhasil dihapus!');
    header('Location: kelas.php'); exit;
}

$editKelas = null;
if ($action === 'edit' && $id) {
    $stmt = $db->prepare("SELECT * FROM kelas WHERE id=?");
    $stmt->execute([$id]);
    $editKelas = $stmt->fetch();
}

$kelasList = $db->query("
    SELECT k.*, u.nama_lengkap as wk_nama,
           COUNT(s.id) as jml_siswa
    FROM kelas k
    LEFT JOIN users u ON k.walikelas_id=u.id
    LEFT JOIN siswa s ON s.kelas_id=k.id AND s.aktif=1
    GROUP BY k.id ORDER BY k.tahun_ajaran DESC, k.tingkat
")->fetchAll();

$wkList = $db->query("SELECT id,nama_lengkap FROM users WHERE role='walikelas' AND aktif=1 ORDER BY nama_lengkap")->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-chalkboard"></i> Data Kelas</div>
        <button class="btn btn-primary btn-sm" onclick="toggleForm('form-tambah')">
            <i class="fas fa-plus"></i> Tambah Kelas
        </button>
    </div>

    <div id="form-tambah" style="display:<?= ($action==='tambah'||$editKelas)?'block':'none' ?>;padding:24px;border-bottom:1px solid var(--border);background:var(--green-50);">
        <h3 style="margin-bottom:16px;color:var(--green-900);"><?= $editKelas?'Edit Kelas':'Tambah Kelas Baru' ?></h3>
        <form method="POST" action="kelas.php?action=<?= $editKelas?'edit&id='.$editKelas['id']:'tambah' ?>">
            <div class="form-row cols-3">
                <div class="form-group">
                    <label>Nama Kelas *</label>
                    <input type="text" name="nama_kelas" required placeholder="cth: 1A, 2B" value="<?= htmlspecialchars($editKelas['nama_kelas']??'') ?>">
                </div>
                <div class="form-group">
                    <label>Tingkat *</label>
                    <select name="tingkat" required>
                        <?php for ($i=1;$i<=6;$i++): ?>
                        <option value="<?= $i ?>" <?= ($editKelas['tingkat']??'') == $i ? 'selected' : '' ?>>Kelas <?= $i ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tahun Ajaran *</label>
                    <input type="text" name="tahun_ajaran" required placeholder="cth: 2024/2025" value="<?= htmlspecialchars($editKelas['tahun_ajaran']??TAHUN_AJARAN) ?>">
                </div>
            </div>
            <div class="form-group" style="max-width:320px;">
                <label>Wali Kelas</label>
                <select name="walikelas_id">
                    <option value="">-- Belum Ditentukan --</option>
                    <?php foreach ($wkList as $wk): ?>
                    <option value="<?= $wk['id'] ?>" <?= ($editKelas['walikelas_id']??'') == $wk['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($wk['nama_lengkap']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="btn-group">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
                <a href="kelas.php" class="btn btn-secondary"><i class="fas fa-times"></i> Batal</a>
            </div>
        </form>
    </div>

    <div class="table-responsive">
        <table>
            <thead><tr>
                <th>No</th><th>Nama Kelas</th><th>Tingkat</th><th>Tahun Ajaran</th>
                <th>Wali Kelas</th><th>Jumlah Siswa</th><th>Aksi</th>
            </tr></thead>
            <tbody>
            <?php if (empty($kelasList)): ?>
            <tr><td colspan="7" class="no-data"><i class="fas fa-chalkboard"></i> Belum ada kelas</td></tr>
            <?php else: ?>
            <?php foreach ($kelasList as $i => $k): ?>
            <tr>
                <td><?= $i+1 ?></td>
                <td><strong><?= htmlspecialchars($k['nama_kelas']) ?></strong></td>
                <td>Kelas <?= $k['tingkat'] ?></td>
                <td><?= htmlspecialchars($k['tahun_ajaran']) ?></td>
                <td><?= $k['wk_nama'] ? htmlspecialchars($k['wk_nama']) : '<span class="text-muted">Belum ditentukan</span>' ?></td>
                <td><span class="badge badge-info"><?= $k['jml_siswa'] ?> siswa</span></td>
                <td>
                    <div class="btn-group">
                        <a href="kelas.php?action=edit&id=<?= $k['id'] ?>" class="btn btn-secondary btn-xs"><i class="fas fa-edit"></i></a>
                        <a href="#" onclick="confirmDelete('kelas.php?action=hapus&id=<?= $k['id'] ?>','Kelas <?= htmlspecialchars($k['nama_kelas']) ?>')" class="btn btn-danger btn-xs"><i class="fas fa-trash"></i></a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>function toggleForm(id){const el=document.getElementById(id);el.style.display=el.style.display==='none'?'block':'none';}</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
