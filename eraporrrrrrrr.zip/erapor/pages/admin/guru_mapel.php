<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('admin');
$db = getDB();
$pageTitle = 'Penugasan Guru';

$action = $_GET['action'] ?? '';
$id     = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $guru_id      = (int)$_POST['guru_id'];
    $mapel_id     = (int)$_POST['mapel_id'];
    $kelas_id     = (int)$_POST['kelas_id'];
    $tahun_ajaran = $_POST['tahun_ajaran'];
    $semester     = (int)$_POST['semester'];
    try {
        if ($action === 'tambah') {
            $db->prepare("INSERT INTO guru_mapel (guru_id,mapel_id,kelas_id,tahun_ajaran,semester) VALUES (?,?,?,?,?)")
               ->execute([$guru_id,$mapel_id,$kelas_id,$tahun_ajaran,$semester]);
            flash('success','Penugasan berhasil ditambahkan!');
        } elseif ($action === 'edit' && $id) {
            $db->prepare("UPDATE guru_mapel SET guru_id=?,mapel_id=?,kelas_id=?,tahun_ajaran=?,semester=? WHERE id=?")
               ->execute([$guru_id,$mapel_id,$kelas_id,$tahun_ajaran,$semester,$id]);
            flash('success','Penugasan berhasil diperbarui!');
        }
    } catch (Exception $e) { flash('error','Penugasan sudah ada atau terjadi kesalahan!'); }
    header('Location: guru_mapel.php'); exit;
}

if ($action === 'hapus' && $id) {
    $db->prepare("DELETE FROM guru_mapel WHERE id=?")->execute([$id]);
    flash('success','Penugasan dihapus!');
    header('Location: guru_mapel.php'); exit;
}

$editGM = null;
if ($action === 'edit' && $id) {
    $stmt = $db->prepare("SELECT * FROM guru_mapel WHERE id=?"); $stmt->execute([$id]);
    $editGM = $stmt->fetch();
}

$gmList = $db->query("
    SELECT gm.*, u.nama_lengkap as guru_nama, m.nama as mapel_nama, m.kode as mapel_kode, k.nama_kelas
    FROM guru_mapel gm
    JOIN users u ON gm.guru_id=u.id
    JOIN mata_pelajaran m ON gm.mapel_id=m.id
    JOIN kelas k ON gm.kelas_id=k.id
    ORDER BY k.tingkat, u.nama_lengkap, m.nama
")->fetchAll();

$guruList  = $db->query("SELECT id,nama_lengkap FROM users WHERE role='guru' AND aktif=1 ORDER BY nama_lengkap")->fetchAll();
$mapelList = $db->query("SELECT id,kode,nama FROM mata_pelajaran ORDER BY nama")->fetchAll();
$kelasList = $db->query("SELECT id,nama_kelas,tahun_ajaran FROM kelas ORDER BY tingkat,nama_kelas")->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>
<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-link"></i> Penugasan Guru - Mata Pelajaran</div>
        <button class="btn btn-primary btn-sm" onclick="toggleForm('form-tambah')"><i class="fas fa-plus"></i> Tambah Penugasan</button>
    </div>

    <div id="form-tambah" style="display:<?= ($action==='tambah'||$editGM)?'block':'none' ?>;padding:24px;border-bottom:1px solid var(--border);background:var(--green-50);">
        <h3 style="margin-bottom:16px;color:var(--green-900);"><?= $editGM?'Edit Penugasan':'Tambah Penugasan Guru' ?></h3>
        <form method="POST" action="guru_mapel.php?action=<?= $editGM?'edit&id='.$editGM['id']:'tambah' ?>">
            <div class="form-row">
                <div class="form-group">
                    <label>Guru *</label>
                    <select name="guru_id" required>
                        <option value="">-- Pilih Guru --</option>
                        <?php foreach ($guruList as $g): ?>
                        <option value="<?= $g['id'] ?>" <?= ($editGM['guru_id']??'')==$g['id']?'selected':'' ?>><?= htmlspecialchars($g['nama_lengkap']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Mata Pelajaran *</label>
                    <select name="mapel_id" required>
                        <option value="">-- Pilih Mapel --</option>
                        <?php foreach ($mapelList as $m): ?>
                        <option value="<?= $m['id'] ?>" <?= ($editGM['mapel_id']??'')==$m['id']?'selected':'' ?>><?= htmlspecialchars($m['kode'].' - '.$m['nama']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="form-row cols-3">
                <div class="form-group">
                    <label>Kelas *</label>
                    <select name="kelas_id" required>
                        <option value="">-- Pilih Kelas --</option>
                        <?php foreach ($kelasList as $k): ?>
                        <option value="<?= $k['id'] ?>" <?= ($editGM['kelas_id']??'')==$k['id']?'selected':'' ?>><?= htmlspecialchars($k['nama_kelas']) ?> (<?= $k['tahun_ajaran'] ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tahun Ajaran *</label>
                    <input type="text" name="tahun_ajaran" required value="<?= htmlspecialchars($editGM['tahun_ajaran']??TAHUN_AJARAN) ?>">
                </div>
                <div class="form-group">
                    <label>Semester *</label>
                    <select name="semester">
                        <option value="1" <?= ($editGM['semester']??1)==1?'selected':'' ?>>Semester 1</option>
                        <option value="2" <?= ($editGM['semester']??1)==2?'selected':'' ?>>Semester 2</option>
                    </select>
                </div>
            </div>
            <div class="btn-group">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
                <a href="guru_mapel.php" class="btn btn-secondary"><i class="fas fa-times"></i> Batal</a>
            </div>
        </form>
    </div>

    <div class="table-responsive">
        <table>
            <thead><tr><th>No</th><th>Guru</th><th>Mata Pelajaran</th><th>Kelas</th><th>Tahun Ajaran</th><th>Semester</th><th>Aksi</th></tr></thead>
            <tbody>
            <?php if (empty($gmList)): ?>
            <tr><td colspan="7" class="no-data"><i class="fas fa-link"></i> Belum ada penugasan</td></tr>
            <?php else: ?>
            <?php foreach ($gmList as $i => $gm): ?>
            <tr>
                <td><?= $i+1 ?></td>
                <td><?= htmlspecialchars($gm['guru_nama']) ?></td>
                <td><span class="badge badge-success"><?= htmlspecialchars($gm['mapel_kode']) ?></span> <?= htmlspecialchars($gm['mapel_nama']) ?></td>
                <td><span class="badge badge-info"><?= htmlspecialchars($gm['nama_kelas']) ?></span></td>
                <td><?= htmlspecialchars($gm['tahun_ajaran']) ?></td>
                <td>Semester <?= $gm['semester'] ?></td>
                <td>
                    <div class="btn-group">
                        <a href="guru_mapel.php?action=edit&id=<?= $gm['id'] ?>" class="btn btn-secondary btn-xs"><i class="fas fa-edit"></i></a>
                        <a href="#" onclick="confirmDelete('guru_mapel.php?action=hapus&id=<?= $gm['id'] ?>','penugasan ini')" class="btn btn-danger btn-xs"><i class="fas fa-trash"></i></a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<script>function toggleForm(id){const el=document.getElementById(id);el.style.display=el.style.display==='none'?'block':'none';}</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
