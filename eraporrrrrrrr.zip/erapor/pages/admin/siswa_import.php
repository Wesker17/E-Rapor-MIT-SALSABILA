<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('admin');
require_once __DIR__ . '/../../includes/XlsxReader.php';
$db = getDB();
$pageTitle = 'Import Data Siswa';

// -------------------------------------------------
// Download template CSV (bisa langsung dibuka/diisi di Excel)
// -------------------------------------------------
if (($_GET['action'] ?? '') === 'template') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="template_import_siswa.csv"');
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF"); // BOM agar Excel baca UTF-8 dgn benar
    fputcsv($out, ['NIS', 'NISN', 'Nama Lengkap', 'Jenis Kelamin', 'Tempat Lahir', 'Tanggal Lahir', 'Kelas', 'Alamat']);
    fputcsv($out, ['2024001', '0012345678', 'Ahmad Fauzan', 'L', 'Jakarta', '2015-05-12', '1A', 'Jl. Melati No. 1']);
    fputcsv($out, ['2024002', '0012345679', 'Siti Aminah', 'P', 'Bandung', '2015-08-20', '1A', 'Jl. Mawar No. 2']);
    fclose($out);
    exit;
}

// -------------------------------------------------
// Helper
// -------------------------------------------------
function normalizeExcelDate($value)
{
    $value = trim((string)$value);
    if ($value === '') return null;

    if (is_numeric($value)) {
        // Serial date Excel (basis 1899-12-30)
        $timestamp = ((float)$value - 25569) * 86400;
        if ($timestamp <= 0) return null;
        return gmdate('Y-m-d', (int)$timestamp);
    }

    $formats = ['d/m/Y', 'd-m-Y', 'Y-m-d', 'd.m.Y', 'j/n/Y'];
    foreach ($formats as $fmt) {
        $d = DateTime::createFromFormat($fmt, $value);
        if ($d instanceof DateTime) {
            return $d->format('Y-m-d');
        }
    }
    $ts = strtotime($value);
    return $ts !== false ? date('Y-m-d', $ts) : null;
}

function nisExists($db, $nis)
{
    $stmt = $db->prepare("SELECT COUNT(*) FROM siswa WHERE nis = ?");
    $stmt->execute([$nis]);
    return (bool)$stmt->fetchColumn();
}

// -------------------------------------------------
// Data kelas untuk pencocokan nama kelas -> kelas_id
// -------------------------------------------------
$kelasList = $db->query("SELECT * FROM kelas ORDER BY tahun_ajaran DESC, tingkat, nama_kelas")->fetchAll();
$kelasMap = [];
foreach ($kelasList as $k) {
    $key = strtolower(trim($k['nama_kelas']));
    if (!isset($kelasMap[$key]) || $k['tahun_ajaran'] === TAHUN_AJARAN) {
        $kelasMap[$key] = $k['id'];
    }
}

$step = 'upload';
$previewRows = [];
$errorGlobal = '';

// -------------------------------------------------
// STEP 2: konfirmasi -> eksekusi insert ke database
// -------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['step'] ?? '') === 'konfirmasi') {
    $rows = $_SESSION['import_siswa_rows'] ?? [];
    $sukses = 0;
    $gagal = 0;
    $errors = [];

    foreach ($rows as $idx => $row) {
        if (!empty($row['_error'])) {
            $gagal++;
            continue;
        }
        try {
            $stmt = $db->prepare("INSERT INTO siswa (nis,nisn,nama_lengkap,jenis_kelamin,tempat_lahir,tanggal_lahir,alamat,kelas_id,aktif) VALUES (?,?,?,?,?,?,?,?,1)");
            $stmt->execute([
                $row['nis'], $row['nisn'], $row['nama_lengkap'], $row['jenis_kelamin'],
                $row['tempat_lahir'], $row['tanggal_lahir'], $row['alamat'], $row['kelas_id']
            ]);
            $sukses++;
        } catch (Exception $e) {
            $gagal++;
            $errors[] = 'Baris ' . ($idx + 2) . ": NIS {$row['nis']} gagal disimpan (kemungkinan NIS/NISN duplikat).";
        }
    }

    unset($_SESSION['import_siswa_rows']);

    $msg = "$sukses siswa berhasil diimport.";
    if ($gagal) $msg .= " $gagal baris dilewati/gagal.";
    flash($sukses > 0 ? 'success' : 'error', $msg);
    if (!empty($errors)) {
        $_SESSION['import_errors'] = $errors;
    }
    header('Location: siswa.php');
    exit;
}

// -------------------------------------------------
// STEP 1: upload file -> parse -> tampilkan preview
// -------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['step'] ?? '') === 'upload') {
    if (!isset($_FILES['file_excel']) || $_FILES['file_excel']['error'] !== UPLOAD_ERR_OK) {
        $errorGlobal = 'Silakan pilih file Excel (.xlsx) atau CSV terlebih dahulu.';
    } else {
        $file = $_FILES['file_excel'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        try {
            if ($ext === 'xlsx') {
                $rawRows = XlsxReader::read($file['tmp_name']);
            } elseif ($ext === 'csv') {
                $content = file_get_contents($file['tmp_name']);
                if ($content === false) $content = '';
                // Hapus BOM UTF-8 (sering ditambahkan Excel) agar header "NIS" tidak terbaca "\xEF\xBB\xBFNIS"
                $content = preg_replace('/^\xEF\xBB\xBF/', '', $content);

                // Deteksi delimiter: sebagian Excel (setting regional Indonesia) memakai titik koma, bukan koma
                $firstLine = strtok($content, "\r\n");
                $delimiter = (substr_count((string)$firstLine, ';') > substr_count((string)$firstLine, ',')) ? ';' : ',';

                $rawRows = [];
                foreach (preg_split('/\r\n|\r|\n/', $content) as $line) {
                    if (trim($line) === '') continue;
                    $rawRows[] = str_getcsv($line, $delimiter);
                }
            } elseif ($ext === 'xls') {
                throw new Exception('Format .xls (Excel lama) belum didukung. Silakan simpan file sebagai .xlsx atau .csv terlebih dahulu.');
            } else {
                throw new Exception('Format file tidak didukung. Gunakan file .xlsx atau .csv.');
            }

            if (empty($rawRows)) {
                throw new Exception('File kosong atau tidak dapat dibaca.');
            }

            // Pemetaan header (fleksibel: tidak harus urutan kolom sama persis dengan template)
            $header = array_map(function ($h) {
                $h = preg_replace('/^\xEF\xBB\xBF/', '', (string)$h); // jaga-jaga jika masih ada BOM tersisa
                return strtolower(trim($h));
            }, $rawRows[0]);

            $aliases = [
                'nis'            => ['nis'],
                'nisn'           => ['nisn'],
                'nama_lengkap'   => ['nama_lengkap', 'nama lengkap', 'nama'],
                'jenis_kelamin'  => ['jenis_kelamin', 'jenis kelamin', 'jk', 'l/p'],
                'tempat_lahir'   => ['tempat_lahir', 'tempat lahir'],
                'tanggal_lahir'  => ['tanggal_lahir', 'tanggal lahir', 'tgl lahir'],
                'alamat'         => ['alamat'],
                'kelas'          => ['kelas', 'nama_kelas', 'nama kelas'],
            ];
            $colIndex = [];
            foreach ($aliases as $field => $names) {
                foreach ($names as $n) {
                    $idx = array_search($n, $header, true);
                    if ($idx !== false) {
                        $colIndex[$field] = $idx;
                        break;
                    }
                }
            }

            if (!isset($colIndex['nis']) || !isset($colIndex['nama_lengkap'])) {
                throw new Exception('Kolom wajib "NIS" dan "Nama Lengkap" tidak ditemukan. Pastikan header kolom sesuai template.');
            }

            $rows = [];
            $nisInFile = [];

            for ($i = 1; $i < count($rawRows); $i++) {
                $r = $rawRows[$i];
                $isEmptyRow = true;
                foreach ($r as $v) {
                    if (trim((string)$v) !== '') { $isEmptyRow = false; break; }
                }
                if ($isEmptyRow) continue;

                $get = function ($field) use ($r, $colIndex) {
                    return isset($colIndex[$field], $r[$colIndex[$field]]) ? trim((string)$r[$colIndex[$field]]) : '';
                };

                $nis = $get('nis');
                $nisn = $get('nisn') ?: null;
                $nama = $get('nama_lengkap');

                $jkRaw = strtoupper($get('jenis_kelamin'));
                if (in_array($jkRaw, ['L', 'P'], true)) {
                    $jk = $jkRaw;
                } elseif (str_starts_with($jkRaw, 'LAKI')) {
                    $jk = 'L';
                } elseif (str_starts_with($jkRaw, 'PER')) {
                    $jk = 'P';
                } else {
                    $jk = '';
                }

                $tempatLahir = $get('tempat_lahir');
                $tgl = normalizeExcelDate($get('tanggal_lahir'));
                $alamat = $get('alamat');
                $kelasNama = $get('kelas');
                $kelasId = $kelasNama !== '' ? ($kelasMap[strtolower($kelasNama)] ?? null) : null;

                $error = '';
                if ($nis === '') {
                    $error = 'NIS kosong';
                } elseif (isset($nisInFile[$nis])) {
                    $error = 'NIS duplikat dalam file';
                } elseif (nisExists($db, $nis)) {
                    $error = 'NIS sudah terdaftar di database';
                } elseif ($nama === '') {
                    $error = 'Nama lengkap kosong';
                } elseif ($jk === '') {
                    $error = 'Jenis kelamin harus diisi L atau P';
                } elseif ($kelasNama !== '' && $kelasId === null) {
                    $error = "Kelas \"$kelasNama\" tidak ditemukan";
                }

                if ($nis !== '') $nisInFile[$nis] = true;

                $rows[] = [
                    'nis' => $nis, 'nisn' => $nisn, 'nama_lengkap' => $nama, 'jenis_kelamin' => $jk,
                    'tempat_lahir' => $tempatLahir, 'tanggal_lahir' => $tgl, 'alamat' => $alamat,
                    'kelas_id' => $kelasId, 'kelas_nama' => $kelasNama, '_error' => $error,
                ];
            }

            if (empty($rows)) {
                throw new Exception('Tidak ada baris data yang bisa dibaca dari file (cek kembali isi file).');
            }

            $_SESSION['import_siswa_rows'] = $rows;
            $previewRows = $rows;
            $step = 'preview';
        } catch (Exception $e) {
            $errorGlobal = $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-file-import"></i> Import Data Siswa dari Excel</div>
        <a href="siswa.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Kembali</a>
    </div>

    <?php if ($errorGlobal): ?>
    <div style="margin:20px 24px 0;">
        <div class="alert alert-error"><i class="fas fa-times-circle"></i> <?= htmlspecialchars($errorGlobal) ?></div>
    </div>
    <?php endif; ?>

    <?php if ($step === 'upload'): ?>
    <div style="padding:24px;">
        <div style="background:var(--green-50);border:1px solid var(--border);border-radius:10px;padding:18px 20px;margin-bottom:22px;">
            <h3 style="margin-bottom:10px;color:var(--green-900);font-size:15px;"><i class="fas fa-circle-info"></i> Petunjuk</h3>
            <ol style="margin:0 0 10px 20px;font-size:14px;line-height:1.8;color:var(--text-muted);">
                <li>Unduh template terlebih dahulu, lalu isi data siswa mengikuti kolom yang tersedia.</li>
                <li>Kolom <strong>NIS</strong> dan <strong>Nama Lengkap</strong> wajib diisi. Kolom lain boleh dikosongkan.</li>
                <li>Kolom <strong>Jenis Kelamin</strong> diisi dengan <code>L</code> atau <code>P</code>.</li>
                <li>Kolom <strong>Kelas</strong> diisi sesuai nama kelas yang sudah ada di menu Data Kelas (contoh: <code>1A</code>). Boleh dikosongkan jika belum ada kelas.</li>
                <li>Setelah file diunggah, sistem akan menampilkan pratinjau data sebelum benar-benar disimpan.</li>
            </ol>
            <a href="siswa_import.php?action=template" class="btn btn-primary btn-sm">
                <i class="fas fa-download"></i> Download Template (.csv)
            </a>
        </div>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="step" value="upload">
            <div class="form-group">
                <label>Pilih File Excel (.xlsx) atau CSV *</label>
                <input type="file" name="file_excel" accept=".xlsx,.csv" required>
                <small style="color:var(--text-muted);display:block;margin-top:6px;">
                    Format didukung: <strong>.xlsx</strong> dan <strong>.csv</strong>. Untuk file .xls lama, simpan ulang sebagai .xlsx.
                </small>
            </div>
            <div class="btn-group">
                <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Unggah &amp; Pratinjau</button>
            </div>
        </form>
    </div>

    <?php elseif ($step === 'preview'): ?>
        <?php
        $validCount = 0;
        $invalidCount = 0;
        foreach ($previewRows as $r) {
            if ($r['_error']) $invalidCount++; else $validCount++;
        }
        ?>
    <div style="padding:16px 24px;border-bottom:1px solid var(--border);display:flex;gap:16px;flex-wrap:wrap;align-items:center;">
        <span class="badge badge-success"><?= $validCount ?> baris valid</span>
        <?php if ($invalidCount): ?>
        <span class="badge badge-danger"><?= $invalidCount ?> baris bermasalah (akan dilewati)</span>
        <?php endif; ?>
        <span style="margin-left:auto;font-size:13px;color:var(--text-muted);">Total <?= count($previewRows) ?> baris terbaca</span>
    </div>

    <div class="table-responsive">
        <table>
            <thead><tr>
                <th>No</th><th>NIS</th><th>NISN</th><th>Nama Lengkap</th><th>L/P</th>
                <th>Tempat, Tgl Lahir</th><th>Kelas</th><th>Alamat</th><th>Status</th>
            </tr></thead>
            <tbody>
            <?php foreach ($previewRows as $i => $r): ?>
            <tr style="<?= $r['_error'] ? 'background:#fef2f2;' : '' ?>">
                <td><?= $i + 1 ?></td>
                <td><code><?= htmlspecialchars($r['nis']) ?></code></td>
                <td><?= htmlspecialchars($r['nisn'] ?? '-') ?></td>
                <td><?= htmlspecialchars($r['nama_lengkap']) ?></td>
                <td><?= htmlspecialchars($r['jenis_kelamin'] ?: '-') ?></td>
                <td><?= htmlspecialchars($r['tempat_lahir'] ?: '-') ?><?= $r['tanggal_lahir'] ? ', ' . date('d/m/Y', strtotime($r['tanggal_lahir'])) : '' ?></td>
                <td><?= htmlspecialchars($r['kelas_nama'] ?: '-') ?></td>
                <td><?= htmlspecialchars($r['alamat'] ?: '-') ?></td>
                <td>
                    <?php if ($r['_error']): ?>
                        <span class="badge badge-danger" title="<?= htmlspecialchars($r['_error']) ?>"><i class="fas fa-triangle-exclamation"></i> <?= htmlspecialchars($r['_error']) ?></span>
                    <?php else: ?>
                        <span class="badge badge-success"><i class="fas fa-check"></i> Siap diimport</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div style="padding:20px 24px;display:flex;gap:10px;">
        <form method="POST">
            <input type="hidden" name="step" value="konfirmasi">
            <button type="submit" class="btn btn-primary" <?= $validCount === 0 ? 'disabled' : '' ?>>
                <i class="fas fa-check"></i> Import <?= $validCount ?> Siswa Sekarang
            </button>
        </form>
        <a href="siswa_import.php" class="btn btn-secondary"><i class="fas fa-rotate-left"></i> Unggah Ulang</a>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
