<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('admin');
$db = getDB();
$pageTitle = 'Mata Pelajaran';

$action = $_GET['action'] ?? '';
$id     = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kode     = strtoupper(trim($_POST['kode']));
    $nama     = trim($_POST['nama']);
    $kelompok = $_POST['kelompok'];
    try {
        if ($action === 'tambah') {
            $db->prepare("INSERT INTO mata_pelajaran (kode,nama,kelompok) VALUES (?,?,?)")->execute([$kode,$nama,$kelompok]);
            flash('success','Mata pelajaran berhasil ditambahkan!');
        } elseif ($action === 'edit' && $id) {
            $db->prepare("UPDATE mata_pelajaran SET kode=?,nama=?,kelompok=? WHERE id=?")->execute([$kode,$nama,$kelompok,$id]);
            flash('success','Mata pelajaran berhasil diperbarui!');
        }
    } catch (Exception $e) { flash('error','Kode mapel sudah ada!'); }
    header('Location: mapel.php'); exit;
}

if ($action === 'hapus' && $id) {
    $db->prepare("DELETE FROM mata_pelajaran WHERE id=?")->execute([$id]);
    flash('success','Mata pelajaran dihapus!');
    header('Location: mapel.php'); exit;
}

$editMapel = null;
if ($action === 'edit' && $id) {
    $stmt = $db->prepare("SELECT * FROM mata_pelajaran WHERE id=?"); $stmt->execute([$id]);
    $editMapel = $stmt->fetch();
}

$mapelList = $db->query("SELECT m.*, COUNT(gm.id) as jml_guru FROM mata_pelajaran m LEFT JOIN guru_mapel gm ON gm.mapel_id=m.id GROUP BY m.id ORDER BY m.kelompok, m.nama")->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>
<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-book"></i> Data Mata Pelajaran</div>
        <button class="btn btn-primary btn-sm" onclick="toggleForm('form-tambah')"><i class="fas fa-plus"></i> Tambah Mapel</button>
    </div>

    <div id="form-tambah" style="display:<?= ($action==='tambah'||$editMapel)?'block':'none' ?>;padding:24px;border-bottom:1px solid var(--border);background:var(--green-50);">
        <h3 style="margin-bottom:16px;color:var(--green-900);"><?= $editMapel?'Edit Mata Pelajaran':'Tambah Mata Pelajaran' ?></h3>
        <form method="POST" action="mapel.php?action=<?= $editMapel?'edit&id='.$editMapel['id']:'tambah' ?>">
            <div class="form-row cols-3">
                <div class="form-group">
                    <label>Kode Mapel *</label>
                    <input type="text" name="kode" required maxlength="10" placeholder="cth: MTK, BIN" value="<?= htmlspecialchars($editMapel['kode']??'') ?>" style="text-transform:uppercase;">
                </div>
                <div class="form-group">
                    <label>Nama Mata Pelajaran *</label>
                    <input type="text" name="nama" required value="<?= htmlspecialchars($editMapel['nama']??'') ?>">
                </div>
                <div class="form-group">
                    <label>Kelompok</label>
                    <select name="kelompok">
                        <option value="A" <?= ($editMapel['kelompok']??'')==='A'?'selected':'' ?>>A - Umum/Wajib</option>
                        <option value="B" <?= ($editMapel['kelompok']??'')==='B'?'selected':'' ?>>B - Pilihan</option>
                        <option value="C" <?= ($editMapel['kelompok']??'')==='C'?'selected':'' ?>>C - Muatan Lokal</option>
                    </select>
                </div>
            </div>
            <div class="btn-group">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
                <a href="mapel.php" class="btn btn-secondary"><i class="fas fa-times"></i> Batal</a>
            </div>
        </form>
    </div>

    <div class="table-responsive">
        <table>
            <thead><tr><th>No</th><th>Kode</th><th>Nama Mata Pelajaran</th><th>Kelompok</th><th>Penggunaan</th><th>Aksi</th></tr></thead>
            <tbody>
            <?php if (empty($mapelList)): ?>
            <tr><td colspan="6" class="no-data"><i class="fas fa-book"></i> Belum ada mata pelajaran</td></tr>
            <?php else: ?>
            <?php foreach ($mapelList as $i => $m): ?>
            <tr>
                <td><?= $i+1 ?></td>
                <td><span class="badge badge-success"><?= htmlspecialchars($m['kode']) ?></span></td>
                <td><strong><?= htmlspecialchars($m['nama']) ?></strong></td>
                <td><?= ['A'=>'Umum/Wajib','B'=>'Pilihan','C'=>'Muatan Lokal'][$m['kelompok']] ?></td>
                <td><?= $m['jml_guru'] ?> penugasan</td>
                <td>
                    <div class="btn-group">
                        <a href="mapel.php?action=edit&id=<?= $m['id'] ?>" class="btn btn-secondary btn-xs"><i class="fas fa-edit"></i></a>
                        <a href="#" onclick="confirmDelete('mapel.php?action=hapus&id=<?= $m['id'] ?>','<?= htmlspecialchars($m['nama']) ?>')" class="btn btn-danger btn-xs"><i class="fas fa-trash"></i></a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<script>function toggleForm(id){const el=document.getElementById(id);el.style.display=el.style.display==='none'?'block':'none';}</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
