<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('admin');
$db = getDB();
$pageTitle = 'Manajemen Siswa';

$action = $_GET['action'] ?? '';
$id     = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nis          = trim($_POST['nis']);
    $nisn         = trim($_POST['nisn']) ?: null;
    $nama         = trim($_POST['nama_lengkap']);
    $jk           = $_POST['jenis_kelamin'];
    $ttl_tempat   = trim($_POST['tempat_lahir']);
    $ttl_tgl      = $_POST['tanggal_lahir'] ?: null;
    $alamat       = trim($_POST['alamat']);
    $kelas_id     = $_POST['kelas_id'] ?: null;
    $aktif        = isset($_POST['aktif']) ? 1 : 0;

    try {
        if ($action === 'tambah') {
            $db->prepare("INSERT INTO siswa (nis,nisn,nama_lengkap,jenis_kelamin,tempat_lahir,tanggal_lahir,alamat,kelas_id,aktif) VALUES (?,?,?,?,?,?,?,?,?)")
               ->execute([$nis,$nisn,$nama,$jk,$ttl_tempat,$ttl_tgl,$alamat,$kelas_id,$aktif]);
            flash('success','Siswa berhasil ditambahkan!');
        } elseif ($action === 'edit' && $id) {
            $db->prepare("UPDATE siswa SET nis=?,nisn=?,nama_lengkap=?,jenis_kelamin=?,tempat_lahir=?,tanggal_lahir=?,alamat=?,kelas_id=?,aktif=? WHERE id=?")
               ->execute([$nis,$nisn,$nama,$jk,$ttl_tempat,$ttl_tgl,$alamat,$kelas_id,$aktif,$id]);
            flash('success','Data siswa berhasil diperbarui!');
        }
    } catch (Exception $e) {
        flash('error','NIS sudah terdaftar!');
    }
    header('Location: siswa.php'); exit;
}

if ($action === 'hapus' && $id) {
    $db->prepare("DELETE FROM siswa WHERE id=?")->execute([$id]);
    flash('success','Siswa berhasil dihapus!');
    header('Location: siswa.php'); exit;
}

$editSiswa = null;
if ($action === 'edit' && $id) {
    $stmt = $db->prepare("SELECT * FROM siswa WHERE id=?");
    $stmt->execute([$id]);
    $editSiswa = $stmt->fetch();
}

$filterKelas = $_GET['kelas_id'] ?? '';
$search      = $_GET['q'] ?? '';
$whereClause = "WHERE s.aktif=1";
$params = [];
if ($filterKelas) { $whereClause .= " AND s.kelas_id=?"; $params[] = $filterKelas; }
if ($search) { $whereClause .= " AND (s.nama_lengkap LIKE ? OR s.nis LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }

$stmt = $db->prepare("
    SELECT s.*, k.nama_kelas
    FROM siswa s
    LEFT JOIN kelas k ON s.kelas_id=k.id
    $whereClause ORDER BY k.tingkat, s.nama_lengkap
");
$stmt->execute($params);
$siswas = $stmt->fetchAll();

$kelasList = $db->query("SELECT * FROM kelas ORDER BY tahun_ajaran DESC, tingkat, nama_kelas")->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-user-graduate"></i> Data Siswa</div>
        <div class="btn-group">
            <a href="siswa_import.php" class="btn btn-secondary btn-sm">
                <i class="fas fa-file-import"></i> Import Excel
            </a>
            <button class="btn btn-primary btn-sm" onclick="toggleForm('form-tambah')">
                <i class="fas fa-plus"></i> Tambah Siswa
            </button>
        </div>
    </div>

    <?php if (!empty($_SESSION['import_errors'])): ?>
    <div style="margin:20px 24px 0;padding:16px 18px;background:#fef2f2;border:1px solid #fecaca;border-radius:10px;">
        <strong style="color:#dc2626;"><i class="fas fa-triangle-exclamation"></i> Sebagian data gagal diimport:</strong>
        <ul style="margin:8px 0 0 20px;font-size:13px;color:#7f1d1d;">
            <?php foreach ($_SESSION['import_errors'] as $err): ?>
            <li><?= htmlspecialchars($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php unset($_SESSION['import_errors']); endif; ?>

    <div id="form-tambah" style="display:<?= ($action==='tambah'||$editSiswa)?'block':'none' ?>;padding:24px;border-bottom:1px solid var(--border);background:var(--green-50);">
        <h3 style="margin-bottom:16px;color:var(--green-900);"><?= $editSiswa?'Edit Data Siswa':'Tambah Siswa Baru' ?></h3>
        <form method="POST" action="siswa.php?action=<?= $editSiswa?'edit&id='.$editSiswa['id']:'tambah' ?>">
            <div class="form-row">
                <div class="form-group">
                    <label>NIS *</label>
                    <input type="text" name="nis" required value="<?= htmlspecialchars($editSiswa['nis']??'') ?>">
                </div>
                <div class="form-group">
                    <label>NISN</label>
                    <input type="text" name="nisn" value="<?= htmlspecialchars($editSiswa['nisn']??'') ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Nama Lengkap *</label>
                    <input type="text" name="nama_lengkap" required value="<?= htmlspecialchars($editSiswa['nama_lengkap']??'') ?>">
                </div>
                <div class="form-group">
                    <label>Jenis Kelamin *</label>
                    <select name="jenis_kelamin" required>
                        <option value="L" <?= ($editSiswa['jenis_kelamin']??'')==='L'?'selected':'' ?>>Laki-laki</option>
                        <option value="P" <?= ($editSiswa['jenis_kelamin']??'')==='P'?'selected':'' ?>>Perempuan</option>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Tempat Lahir</label>
                    <input type="text" name="tempat_lahir" value="<?= htmlspecialchars($editSiswa['tempat_lahir']??'') ?>">
                </div>
                <div class="form-group">
                    <label>Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" value="<?= htmlspecialchars($editSiswa['tanggal_lahir']??'') ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Kelas</label>
                    <select name="kelas_id">
                        <option value="">-- Pilih Kelas --</option>
                        <?php
                        $groupTA = '';
                        foreach ($kelasList as $k):
                            if ($k['tahun_ajaran'] !== $groupTA):
                                if ($groupTA !== '') echo '</optgroup>';
                                $groupTA = $k['tahun_ajaran'];
                                echo '<optgroup label="TA ' . htmlspecialchars($groupTA) . ($groupTA === TAHUN_AJARAN ? ' (Aktif)' : '') . '">';
                            endif;
                        ?>
                        <option value="<?= $k['id'] ?>" <?= ($editSiswa['kelas_id']??'') == $k['id']?'selected':'' ?>><?= htmlspecialchars($k['nama_kelas']) ?></option>
                        <?php endforeach; if ($groupTA !== '') echo '</optgroup>'; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Alamat</label>
                    <input type="text" name="alamat" value="<?= htmlspecialchars($editSiswa['alamat']??'') ?>">
                </div>
            </div>
            <div class="form-group">
                <label><input type="checkbox" name="aktif" value="1" <?= ($editSiswa['aktif']??1)?'checked':'' ?>> Siswa Aktif</label>
            </div>
            <div class="btn-group">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
                <a href="siswa.php" class="btn btn-secondary"><i class="fas fa-times"></i> Batal</a>
            </div>
        </form>
    </div>

    <!-- Filter -->
    <div style="padding:16px 24px;border-bottom:1px solid var(--border);display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
        <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
            <input type="text" name="q" placeholder="Cari nama/NIS..." value="<?= htmlspecialchars($search) ?>" style="width:200px;">
            <select name="kelas_id" style="width:150px;">
                <option value="">Semua Kelas</option>
                <?php foreach ($kelasList as $k): ?>
                <option value="<?= $k['id'] ?>" <?= $filterKelas == $k['id']?'selected':'' ?>><?= htmlspecialchars($k['nama_kelas']) ?> (<?= $k['tahun_ajaran'] ?>)</option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i></button>
            <a href="siswa.php" class="btn btn-secondary btn-sm"><i class="fas fa-times"></i></a>
        </form>
        <span style="margin-left:auto;font-size:13px;color:var(--text-muted);"><?= count($siswas) ?> siswa</span>
    </div>

    <div class="table-responsive">
        <table>
            <thead><tr>
                <th>No</th><th>NIS</th><th>Nama Lengkap</th><th>L/P</th>
                <th>Tempat, Tgl Lahir</th><th>Kelas</th><th>Status</th><th>Aksi</th>
            </tr></thead>
            <tbody>
            <?php if (empty($siswas)): ?>
            <tr><td colspan="8" class="no-data"><i class="fas fa-user-graduate"></i> Belum ada data siswa</td></tr>
            <?php else: ?>
            <?php foreach ($siswas as $i => $s): ?>
            <tr>
                <td><?= $i+1 ?></td>
                <td><code><?= htmlspecialchars($s['nis']) ?></code></td>
                <td><strong><?= htmlspecialchars($s['nama_lengkap']) ?></strong></td>
                <td><?= $s['jenis_kelamin']==='L' ? '👦 L' : '👧 P' ?></td>
                <td><?= htmlspecialchars($s['tempat_lahir']??'-') ?><?= $s['tanggal_lahir'] ? ', '.date('d/m/Y',strtotime($s['tanggal_lahir'])) : '' ?></td>
                <td><?= $s['nama_kelas'] ? '<span class="badge badge-info">'.htmlspecialchars($s['nama_kelas']).'</span>' : '<span class="text-muted">-</span>' ?></td>
                <td><?= $s['aktif'] ? '<span class="badge badge-success">Aktif</span>' : '<span class="badge badge-danger">Nonaktif</span>' ?></td>
                <td>
                    <div class="btn-group">
                        <a href="siswa.php?action=edit&id=<?= $s['id'] ?>" class="btn btn-secondary btn-xs"><i class="fas fa-edit"></i></a>
                        <a href="#" onclick="confirmDelete('siswa.php?action=hapus&id=<?= $s['id'] ?>','<?= htmlspecialchars($s['nama_lengkap']) ?>')" class="btn btn-danger btn-xs"><i class="fas fa-trash"></i></a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>function toggleForm(id){const el=document.getElementById(id);el.style.display=el.style.display==='none'?'block':'none';}</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
