<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('admin');
$db = getDB();
$pageTitle = 'Hubungkan Orang Tua & Siswa';

$action = $_GET['action'] ?? '';
$id     = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ortu_id   = (int)$_POST['ortu_id'];
    $siswa_id  = (int)$_POST['siswa_id'];
    $hubungan  = $_POST['hubungan'];
    try {
        $db->prepare("INSERT INTO ortu_siswa (ortu_id, siswa_id, hubungan) VALUES (?,?,?)")
           ->execute([$ortu_id, $siswa_id, $hubungan]);
        flash('success', 'Relasi orang tua-siswa berhasil ditambahkan!');
    } catch (Exception $e) {
        flash('error', 'Relasi sudah ada atau terjadi kesalahan!');
    }
    header('Location: ortu_siswa.php'); exit;
}

if ($action === 'hapus' && $id) {
    $db->prepare("DELETE FROM ortu_siswa WHERE id=?")->execute([$id]);
    flash('success', 'Relasi dihapus!');
    header('Location: ortu_siswa.php'); exit;
}

$relasiList = $db->query("
    SELECT os.*, u.nama_lengkap as ortu_nama, u.username,
           s.nama_lengkap as siswa_nama, s.nis, k.nama_kelas
    FROM ortu_siswa os
    JOIN users u ON os.ortu_id = u.id
    JOIN siswa s ON os.siswa_id = s.id
    LEFT JOIN kelas k ON s.kelas_id = k.id
    ORDER BY u.nama_lengkap, s.nama_lengkap
")->fetchAll();

$ortuList  = $db->query("SELECT id, nama_lengkap, username FROM users WHERE role='ortu' AND aktif=1 ORDER BY nama_lengkap")->fetchAll();
$siswaList = $db->query("SELECT s.id, s.nis, s.nama_lengkap, k.nama_kelas FROM siswa s LEFT JOIN kelas k ON s.kelas_id=k.id WHERE s.aktif=1 ORDER BY s.nama_lengkap")->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-people-arrows"></i> Relasi Orang Tua &harr; Siswa</div>
        <button class="btn btn-primary btn-sm" onclick="toggleForm('form-tambah')">
            <i class="fas fa-plus"></i> Tambah Relasi
        </button>
    </div>

    <!-- Form Tambah -->
    <div id="form-tambah" style="display:none;padding:24px;border-bottom:1px solid var(--border);background:var(--green-50);">
        <h3 style="margin-bottom:16px;color:var(--green-900);">Hubungkan Orang Tua dengan Siswa</h3>
        <form method="POST" action="ortu_siswa.php?action=tambah">
            <div class="form-row cols-3">
                <div class="form-group">
                    <label>Orang Tua / Wali *</label>
                    <select name="ortu_id" required>
                        <option value="">-- Pilih Orang Tua --</option>
                        <?php foreach ($ortuList as $o): ?>
                        <option value="<?= $o['id'] ?>"><?= htmlspecialchars($o['nama_lengkap']) ?> (<?= $o['username'] ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Siswa *</label>
                    <select name="siswa_id" required>
                        <option value="">-- Pilih Siswa --</option>
                        <?php foreach ($siswaList as $s): ?>
                        <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['nama_lengkap']) ?> - <?= $s['nis'] ?> (<?= $s['nama_kelas']??'-' ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Hubungan *</label>
                    <select name="hubungan" required>
                        <option value="Ayah">Ayah</option>
                        <option value="Ibu">Ibu</option>
                        <option value="Wali">Wali</option>
                    </select>
                </div>
            </div>
            <div class="btn-group">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
                <a href="ortu_siswa.php" class="btn btn-secondary"><i class="fas fa-times"></i> Batal</a>
            </div>
        </form>
    </div>

    <div class="table-responsive">
        <table>
            <thead><tr>
                <th>No</th>
                <th>Nama Orang Tua</th>
                <th>Username</th>
                <th>Hubungan</th>
                <th>Nama Siswa</th>
                <th>NIS</th>
                <th>Kelas</th>
                <th>Aksi</th>
            </tr></thead>
            <tbody>
            <?php if (empty($relasiList)): ?>
            <tr><td colspan="8" class="no-data"><i class="fas fa-people-arrows"></i> Belum ada relasi</td></tr>
            <?php else: ?>
            <?php foreach ($relasiList as $i => $r): ?>
            <tr>
                <td><?= $i+1 ?></td>
                <td><strong><?= htmlspecialchars($r['ortu_nama']) ?></strong></td>
                <td><code><?= htmlspecialchars($r['username']) ?></code></td>
                <td><span class="badge badge-info"><?= htmlspecialchars($r['hubungan']) ?></span></td>
                <td><strong><?= htmlspecialchars($r['siswa_nama']) ?></strong></td>
                <td><?= htmlspecialchars($r['nis']) ?></td>
                <td><?= $r['nama_kelas'] ? '<span class="badge badge-success">'.htmlspecialchars($r['nama_kelas']).'</span>' : '-' ?></td>
                <td>
                    <a href="#" onclick="confirmDelete('ortu_siswa.php?action=hapus&id=<?= $r['id'] ?>','relasi ini')" class="btn btn-danger btn-xs">
                        <i class="fas fa-unlink"></i> Hapus
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>function toggleForm(id){const el=document.getElementById(id);el.style.display=el.style.display==='none'?'block':'none';}</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
