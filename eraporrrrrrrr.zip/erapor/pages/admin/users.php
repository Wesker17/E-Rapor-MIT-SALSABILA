<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('admin');
$db = getDB();
$pageTitle = 'Manajemen Pengguna';

// Handle actions
$action = $_GET['action'] ?? '';
$id     = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama     = trim($_POST['nama_lengkap']);
    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);
    $telepon  = trim($_POST['telepon']);
    $role     = $_POST['role'];
    $aktif    = isset($_POST['aktif']) ? 1 : 0;

    if ($action === 'tambah') {
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $stmt = $db->prepare("INSERT INTO users (nama_lengkap, username, email, telepon, role, password, aktif) VALUES (?,?,?,?,?,?,?)");
        try {
            $stmt->execute([$nama, $username, $email, $telepon, $role, $password, $aktif]);
            flash('success', 'Pengguna berhasil ditambahkan!');
        } catch (Exception $e) {
            flash('error', 'Username sudah digunakan!');
        }
    } elseif ($action === 'edit' && $id) {
        $sql = "UPDATE users SET nama_lengkap=?, username=?, email=?, telepon=?, role=?, aktif=?";
        $params = [$nama, $username, $email, $telepon, $role, $aktif];
        if (!empty($_POST['password'])) {
            $sql .= ", password=?";
            $params[] = password_hash($_POST['password'], PASSWORD_DEFAULT);
        }
        $sql .= " WHERE id=?";
        $params[] = $id;
        $db->prepare($sql)->execute($params);
        flash('success', 'Data pengguna berhasil diperbarui!');
    }
    header('Location: users.php'); exit;
}

if ($action === 'hapus' && $id && $id != $_SESSION['user_id']) {
    $db->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
    flash('success', 'Pengguna berhasil dihapus!');
    header('Location: users.php'); exit;
}

// Edit data
$editUser = null;
if ($action === 'edit' && $id) {
    $stmt = $db->prepare("SELECT * FROM users WHERE id=?");
    $stmt->execute([$id]);
    $editUser = $stmt->fetch();
}

// Filter
$filterRole = $_GET['role'] ?? '';
$search     = $_GET['q'] ?? '';
$whereClause = "WHERE 1=1";
$params = [];
if ($filterRole) { $whereClause .= " AND role=?"; $params[] = $filterRole; }
if ($search) { $whereClause .= " AND (nama_lengkap LIKE ? OR username LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }

$stmt = $db->prepare("SELECT * FROM users $whereClause ORDER BY role, nama_lengkap");
$stmt->execute($params);
$users = $stmt->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-users"></i> Data Pengguna</div>
        <button class="btn btn-primary btn-sm" onclick="toggleForm('form-tambah')">
            <i class="fas fa-plus"></i> Tambah Pengguna
        </button>
    </div>

    <!-- Form Tambah/Edit -->
    <div id="form-tambah" style="display:<?= ($action==='tambah'||$editUser)?'block':'none' ?>;padding:24px;border-bottom:1px solid var(--border);background:var(--green-50);">
        <h3 style="margin-bottom:18px;color:var(--green-900);">
            <i class="fas fa-<?= $editUser?'edit':'plus' ?>"></i> <?= $editUser?'Edit Pengguna':'Tambah Pengguna Baru' ?>
        </h3>
        <form method="POST" action="users.php?action=<?= $editUser?'edit&id='.$editUser['id']:'tambah' ?>">
            <div class="form-row">
                <div class="form-group">
                    <label>Nama Lengkap *</label>
                    <input type="text" name="nama_lengkap" required value="<?= htmlspecialchars($editUser['nama_lengkap']??'') ?>">
                </div>
                <div class="form-group">
                    <label>Username *</label>
                    <input type="text" name="username" required value="<?= htmlspecialchars($editUser['username']??'') ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" value="<?= htmlspecialchars($editUser['email']??'') ?>">
                </div>
                <div class="form-group">
                    <label>Telepon</label>
                    <input type="text" name="telepon" value="<?= htmlspecialchars($editUser['telepon']??'') ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Role *</label>
                    <select name="role" required>
                        <option value="">-- Pilih Role --</option>
                        <?php foreach(['admin'=>'Administrator','guru'=>'Guru','walikelas'=>'Wali Kelas','ortu'=>'Orang Tua'] as $k=>$v): ?>
                        <option value="<?= $k ?>" <?= ($editUser['role']??'')===$k?'selected':'' ?>><?= $v ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Password <?= $editUser?'(kosongkan jika tidak diubah)':'' ?> <?= $editUser?'':'*' ?></label>
                    <input type="password" name="password" <?= $editUser?'':'required' ?> placeholder="Min. 6 karakter">
                </div>
            </div>
            <div class="form-group">
                <label><input type="checkbox" name="aktif" value="1" <?= ($editUser['aktif']??1)?'checked':'' ?>> Akun Aktif</label>
            </div>
            <div class="btn-group">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
                <a href="users.php" class="btn btn-secondary"><i class="fas fa-times"></i> Batal</a>
            </div>
        </form>
    </div>

    <!-- Filter -->
    <div style="padding:16px 24px;border-bottom:1px solid var(--border);display:flex;gap:12px;flex-wrap:wrap;">
        <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
            <input type="text" name="q" placeholder="Cari nama / username..." value="<?= htmlspecialchars($search) ?>" style="width:220px;">
            <select name="role" style="width:160px;">
                <option value="">Semua Role</option>
                <?php foreach(['admin'=>'Admin','guru'=>'Guru','walikelas'=>'Wali Kelas','ortu'=>'Orang Tua'] as $k=>$v): ?>
                <option value="<?= $k ?>" <?= $filterRole===$k?'selected':'' ?>><?= $v ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i></button>
            <a href="users.php" class="btn btn-secondary btn-sm"><i class="fas fa-times"></i></a>
        </form>
        <span style="margin-left:auto;font-size:13px;color:var(--text-muted);align-self:center;">
            <?= count($users) ?> pengguna ditemukan
        </span>
    </div>

    <div class="table-responsive">
        <table>
            <thead><tr>
                <th>No</th><th>Nama Lengkap</th><th>Username</th><th>Email</th>
                <th>Telepon</th><th>Role</th><th>Status</th><th>Aksi</th>
            </tr></thead>
            <tbody>
            <?php if (empty($users)): ?>
            <tr><td colspan="8" class="no-data"><i class="fas fa-users"></i> Tidak ada pengguna</td></tr>
            <?php else: ?>
            <?php foreach ($users as $i => $u): ?>
            <tr>
                <td><?= $i+1 ?></td>
                <td><strong><?= htmlspecialchars($u['nama_lengkap']) ?></strong></td>
                <td><code><?= htmlspecialchars($u['username']) ?></code></td>
                <td><?= htmlspecialchars($u['email']??'-') ?></td>
                <td><?= htmlspecialchars($u['telepon']??'-') ?></td>
                <td>
                    <?php
                    $roleLabels = ['admin'=>['Admin','danger'],'guru'=>['Guru','info'],'walikelas'=>['Wali Kelas','warning'],'ortu'=>['Orang Tua','success']];
                    $rl = $roleLabels[$u['role']] ?? [$u['role'],'info'];
                    ?>
                    <span class="badge badge-<?= $rl[1] ?>"><?= $rl[0] ?></span>
                </td>
                <td>
                    <?php if ($u['aktif']): ?>
                    <span class="badge badge-success">Aktif</span>
                    <?php else: ?>
                    <span class="badge badge-danger">Nonaktif</span>
                    <?php endif; ?>
                </td>
                <td>
                    <div class="btn-group">
                        <a href="users.php?action=edit&id=<?= $u['id'] ?>" class="btn btn-secondary btn-xs"><i class="fas fa-edit"></i></a>
                        <?php if ($u['id'] != $_SESSION['user_id']): ?>
                        <a href="#" onclick="confirmDelete('users.php?action=hapus&id=<?= $u['id'] ?>','<?= htmlspecialchars($u['nama_lengkap']) ?>')" class="btn btn-danger btn-xs"><i class="fas fa-trash"></i></a>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function toggleForm(id) {
    const el = document.getElementById(id);
    el.style.display = el.style.display === 'none' ? 'block' : 'none';
}
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
