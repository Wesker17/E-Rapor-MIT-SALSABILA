<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('admin');
$db = getDB();
$pageTitle = 'Rekap Nilai';

$kelas_id = (int)($_GET['kelas_id'] ?? 0);
$kelasList = $db->query("SELECT * FROM kelas WHERE tahun_ajaran='".TAHUN_AJARAN."' ORDER BY tingkat,nama_kelas")->fetchAll();

$rekapData = [];
$mapelList = [];
$siswaList = [];

if ($kelas_id) {
    $mapelList = $db->query("SELECT DISTINCT m.id, m.kode, m.nama FROM mata_pelajaran m JOIN nilai n ON n.mapel_id=m.id WHERE n.kelas_id=$kelas_id AND n.tahun_ajaran='".TAHUN_AJARAN."' AND n.semester=".SEMESTER." ORDER BY m.nama")->fetchAll();
    $siswaList = $db->query("SELECT * FROM siswa WHERE kelas_id=$kelas_id AND aktif=1 ORDER BY nama_lengkap")->fetchAll();
    foreach ($siswaList as $s) {
        $stmt = $db->prepare("SELECT n.*, m.kode FROM nilai n JOIN mata_pelajaran m ON n.mapel_id=m.id WHERE n.siswa_id=? AND n.kelas_id=? AND n.tahun_ajaran=? AND n.semester=?");
        $stmt->execute([$s['id'],$kelas_id,TAHUN_AJARAN,SEMESTER]);
        $nilaiRows = $stmt->fetchAll();
        $nilaiMap = [];
        foreach ($nilaiRows as $nr) { $nilaiMap[$nr['mapel_id']] = $nr; }
        $rekapData[$s['id']] = ['siswa' => $s, 'nilai' => $nilaiMap];
    }
}

require_once __DIR__ . '/../../includes/header.php';
?>
<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-chart-bar"></i> Rekap Nilai Per Kelas</div>
    </div>
    <div style="padding:20px 24px;border-bottom:1px solid var(--border);display:flex;gap:12px;align-items:center;flex-wrap:wrap;">
        <form method="GET" style="display:flex;gap:10px;align-items:center;">
            <select name="kelas_id" style="width:180px;" onchange="this.form.submit()">
                <option value="">-- Pilih Kelas --</option>
                <?php foreach ($kelasList as $k): ?>
                <option value="<?= $k['id'] ?>" <?= $kelas_id==$k['id']?'selected':'' ?>><?= htmlspecialchars($k['nama_kelas']) ?></option>
                <?php endforeach; ?>
            </select>
        </form>
        <?php if ($kelas_id && !empty($siswaList)): ?>
        <button onclick="window.print()" class="btn btn-secondary btn-sm"><i class="fas fa-print"></i> Cetak</button>
        <?php endif; ?>
    </div>
</div>

<?php if ($kelas_id && !empty($siswaList)): ?>
<div class="card">
    <div class="card-header">
        <div class="card-title">
            <?php
            $k = array_values(array_filter($kelasList, fn($x) => $x['id'] == $kelas_id))[0];
            echo '<i class="fas fa-table"></i> Rekap Nilai Kelas '.htmlspecialchars($k['nama_kelas']).' - TA '.TAHUN_AJARAN.' Semester '.SEMESTER;
            ?>
        </div>
    </div>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th rowspan="2">No</th>
                    <th rowspan="2">Nama Siswa</th>
                    <?php foreach ($mapelList as $m): ?>
                    <th colspan="2" style="text-align:center;"><?= htmlspecialchars($m['kode']) ?></th>
                    <?php endforeach; ?>
                    <th rowspan="2">Rata-rata</th>
                    <th rowspan="2">Peringkat</th>
                </tr>
                <tr>
                    <?php foreach ($mapelList as $m): ?>
                    <th style="font-size:10px;">Nilai</th>
                    <th style="font-size:10px;">Pred</th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
            <?php
            // Hitung rata-rata untuk ranking
            $rataData = [];
            foreach ($rekapData as $sid => $rd) {
                $nilaiArr = array_column($rd['nilai'],'nilai_akhir');
                $rataData[$sid] = count($nilaiArr) ? round(array_sum($nilaiArr)/count($nilaiArr),1) : 0;
            }
            arsort($rataData);
            $ranking = array_keys($rataData);

            $no = 1;
            foreach ($rekapData as $sid => $rd):
                $rank = array_search($sid, $ranking) + 1;
                $rata = $rataData[$sid];
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><strong><?= htmlspecialchars($rd['siswa']['nama_lengkap']) ?></strong></td>
                <?php foreach ($mapelList as $m): ?>
                <?php $n = $rd['nilai'][$m['id']] ?? null; ?>
                <td style="text-align:center;"><?= $n ? $n['nilai_akhir'] : '-' ?></td>
                <td style="text-align:center;">
                    <?php if ($n): ?>
                    <span class="pred pred-<?= substr($n['predikat'],0,1) ?>"><?= $n['predikat'] ?></span>
                    <?php else: echo '-'; endif; ?>
                </td>
                <?php endforeach; ?>
                <td style="text-align:center;"><strong class="text-green"><?= $rata ?: '-' ?></strong></td>
                <td style="text-align:center;">
                    <?php if ($rank <= 3): ?>
                    <span class="badge badge-warning"><?= ['🥇','🥈','🥉'][$rank-1] ?> <?= $rank ?></span>
                    <?php else: echo $rank; endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div style="padding:12px 24px;font-size:12px;color:var(--text-muted);border-top:1px solid var(--border);">
        <?php
        $allKode = [];
        foreach ($mapelList as $m) $allKode[] = $m['kode'].' = '.$m['nama'];
        echo 'Keterangan: '.implode(' | ', $allKode);
        ?>
    </div>
</div>
<?php elseif ($kelas_id): ?>
<div class="card"><div class="card-body no-data"><i class="fas fa-inbox"></i><p>Belum ada data nilai untuk kelas ini.</p></div></div>
<?php else: ?>
<div class="card"><div class="card-body no-data"><i class="fas fa-hand-pointer"></i><p>Pilih kelas untuk melihat rekap nilai.</p></div></div>
<?php endif; ?>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
