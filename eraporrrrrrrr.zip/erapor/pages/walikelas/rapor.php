<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('walikelas');
$db = getDB();
$pageTitle = 'Cetak Rapor';

$kelasList = getKelasWalikelas($_SESSION['user_id']);
$kelas = $kelasList[0] ?? null;

if (!$kelas) {
    require_once __DIR__ . '/../../includes/header.php';
    echo '<div class="card"><div class="card-body no-data"><i class="fas fa-exclamation-triangle" style="color:#f59e0b;"></i><p>Anda belum ditugaskan sebagai wali kelas.<br><small style="color:var(--text-muted);">Silakan hubungi Admin untuk mendapatkan penugasan kelas.</small></p></div></div>';
    require_once __DIR__ . '/../../includes/footer.php'; exit;
}

$siswa_id = (int)($_GET['siswa_id'] ?? 0);
$siswas = $db->query("SELECT * FROM siswa WHERE kelas_id={$kelas['id']} AND aktif=1 ORDER BY nama_lengkap")->fetchAll();

// Catatan walikelas
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $siswa_id) {
    $catatan = trim($_POST['catatan_walikelas']);
    $tgl     = $_POST['tanggal_rapor'];
    $db->prepare("
        INSERT INTO catatan_rapor (siswa_id,kelas_id,tahun_ajaran,semester,catatan_walikelas,tanggal_rapor)
        VALUES (?,?,?,?,?,?)
        ON DUPLICATE KEY UPDATE catatan_walikelas=VALUES(catatan_walikelas),tanggal_rapor=VALUES(tanggal_rapor)
    ")->execute([$siswa_id,$kelas['id'],TAHUN_AJARAN,SEMESTER,$catatan,$tgl]);
    flash('success','Catatan rapor disimpan!');
    header("Location: rapor.php?siswa_id=$siswa_id"); exit;
}

$selectedSiswa = null;
$nilaiList = [];
$kehadiran = null;
$catatan = null;

if ($siswa_id) {
    $stmt = $db->prepare("SELECT s.*,k.nama_kelas FROM siswa s JOIN kelas k ON s.kelas_id=k.id WHERE s.id=? AND s.kelas_id=?");
    $stmt->execute([$siswa_id,$kelas['id']]);
    $selectedSiswa = $stmt->fetch();

    if ($selectedSiswa) {
        $stmt = $db->prepare("
            SELECT n.*, m.nama as mapel_nama, m.kode, m.kelompok
            FROM nilai n JOIN mata_pelajaran m ON n.mapel_id=m.id
            WHERE n.siswa_id=? AND n.kelas_id=? AND n.tahun_ajaran=? AND n.semester=?
            ORDER BY m.kelompok, m.nama
        ");
        $stmt->execute([$siswa_id,$kelas['id'],TAHUN_AJARAN,SEMESTER]);
        $nilaiList = $stmt->fetchAll();

        $stmt2 = $db->prepare("SELECT * FROM kehadiran WHERE siswa_id=? AND kelas_id=? AND tahun_ajaran=? AND semester=?");
        $stmt2->execute([$siswa_id,$kelas['id'],TAHUN_AJARAN,SEMESTER]);
        $kehadiran = $stmt2->fetch();

        $stmt3 = $db->prepare("SELECT * FROM catatan_rapor WHERE siswa_id=? AND kelas_id=? AND tahun_ajaran=? AND semester=?");
        $stmt3->execute([$siswa_id,$kelas['id'],TAHUN_AJARAN,SEMESTER]);
        $catatan = $stmt3->fetch();

        $wkUser = getCurrentUser();
    }
}

require_once __DIR__ . '/../../includes/header.php';
?>

<div style="display:grid;grid-template-columns:260px 1fr;gap:24px;">

<!-- Daftar Siswa -->
<div class="card" style="height:fit-content;">
    <div class="card-header"><div class="card-title"><i class="fas fa-list"></i> Pilih Siswa</div></div>
    <div style="padding:8px;">
        <?php foreach ($siswas as $s): ?>
        <a href="rapor.php?siswa_id=<?= $s['id'] ?>"
           style="display:block;padding:10px 14px;border-radius:8px;text-decoration:none;color:var(--text);font-size:13px;font-weight:<?= $siswa_id==$s['id']?'700':'500' ?>;background:<?= $siswa_id==$s['id']?'var(--green-100)':'transparent' ?>;margin-bottom:2px;border:<?= $siswa_id==$s['id']?'1px solid var(--green-300)':'1px solid transparent' ?>;">
            <?= htmlspecialchars($s['nama_lengkap']) ?>
        </a>
        <?php endforeach; ?>
    </div>
</div>

<!-- Rapor -->
<div>
<?php if ($selectedSiswa && !empty($nilaiList)): ?>

<!-- Form Catatan Walikelas -->
<div class="card no-print">
    <div class="card-header"><div class="card-title"><i class="fas fa-pen"></i> Catatan Wali Kelas</div></div>
    <div class="card-body">
        <form method="POST">
            <div class="form-group">
                <label>Catatan / Pesan untuk Orang Tua</label>
                <textarea name="catatan_walikelas" rows="3" placeholder="Tuliskan catatan untuk orang tua siswa..."><?= htmlspecialchars($catatan['catatan_walikelas']??'') ?></textarea>
            </div>
            <div class="form-group" style="max-width:220px;">
                <label>Tanggal Pembagian Rapor</label>
                <input type="date" name="tanggal_rapor" value="<?= $catatan['tanggal_rapor']??date('Y-m-d') ?>">
            </div>
            <div class="btn-group">
                <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Simpan Catatan</button>
                <button type="button" onclick="window.print()" class="btn btn-gold btn-sm"><i class="fas fa-print"></i> Cetak Rapor</button>
            </div>
        </form>
    </div>
</div>

<!-- Rapor Cetak -->
<div class="card rapor-container">
    <!-- Kop Rapor -->
    <div class="rapor-header">
        <div style="display:flex;align-items:center;justify-content:center;gap:16px;margin-bottom:10px;">
            <div style="width:70px;height:70px;background:linear-gradient(135deg,var(--green-600),var(--green-800));border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:28px;color:var(--gold);">
                <i class="fas fa-graduation-cap"></i>
            </div>
            <div>
                <div style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:2px;">Kementerian Agama RI</div>
                <h1 style="font-family:'Amiri',serif;font-size:22px;color:var(--green-900);">SD MIT Salsabila</h1>
                <div style="font-size:12px;color:var(--text-muted);">Jl. Pendidikan No. 1, Kota</div>
            </div>
        </div>
        <div style="background:var(--green-900);color:#fff;padding:8px 20px;border-radius:4px;display:inline-block;font-size:14px;font-weight:700;letter-spacing:2px;margin-top:8px;">
            RAPOR SISWA
        </div>
        <div style="font-size:12px;margin-top:6px;color:var(--text-muted);">
            Tahun Pelajaran <?= TAHUN_AJARAN ?> | Semester <?= SEMESTER ?>
        </div>
    </div>

    <!-- Data Siswa -->
    <dl class="rapor-siswa-info">
        <dt>Nama Siswa</dt>
        <dd><?= htmlspecialchars($selectedSiswa['nama_lengkap']) ?></dd>
        <dt>NIS / NISN</dt>
        <dd><?= htmlspecialchars($selectedSiswa['nis']) ?> / <?= htmlspecialchars($selectedSiswa['nisn']??'-') ?></dd>
        <dt>Kelas</dt>
        <dd><?= htmlspecialchars($selectedSiswa['nama_kelas']) ?></dd>
        <dt>Jenis Kelamin</dt>
        <dd><?= $selectedSiswa['jenis_kelamin']==='L' ? 'Laki-laki' : 'Perempuan' ?></dd>
        <dt>Tempat, Tgl Lahir</dt>
        <dd><?= htmlspecialchars($selectedSiswa['tempat_lahir']??'-') ?><?= $selectedSiswa['tanggal_lahir'] ? ', '.date('d F Y',strtotime($selectedSiswa['tanggal_lahir'])) : '' ?></dd>
        <dt>Wali Kelas</dt>
        <dd><?= htmlspecialchars($wkUser['nama_lengkap']) ?></dd>
    </dl>

    <!-- Tabel Nilai -->
    <h3 style="font-size:14px;font-weight:700;color:var(--green-900);margin-bottom:12px;border-bottom:2px solid var(--green-700);padding-bottom:6px;">A. Capaian Hasil Belajar</h3>
    <table style="font-size:12px;margin-bottom:20px;">
        <thead><tr>
            <th style="width:40px;">No</th>
            <th>Mata Pelajaran</th>
            <th style="text-align:center;width:70px;">Nilai Harian</th>
            <th style="text-align:center;width:60px;">UTS</th>
            <th style="text-align:center;width:60px;">UAS</th>
            <th style="text-align:center;width:70px;">Nilai Akhir</th>
            <th style="text-align:center;width:60px;">Predikat</th>
            <th>Deskripsi Kompetensi</th>
        </tr></thead>
        <tbody>
        <?php
        $no = 1;
        $currentKelompok = '';
        $totalNilai = 0; $countNilai = 0;
        foreach ($nilaiList as $n):
            if ($n['kelompok'] !== $currentKelompok):
                $currentKelompok = $n['kelompok'];
                $label = ['A'=>'Kelompok A - Muatan Umum','B'=>'Kelompok B - Muatan Kejuruan','C'=>'Kelompok C - Muatan Lokal'][$currentKelompok];
        ?>
        <tr><td colspan="8" style="background:var(--green-50);font-weight:700;font-size:11px;color:var(--green-800);padding:6px 12px;"><?= $label ?></td></tr>
        <?php endif; $totalNilai += $n['nilai_akhir']; $countNilai++; ?>
        <tr>
            <td style="text-align:center;"><?= $no++ ?></td>
            <td><?= htmlspecialchars($n['mapel_nama']) ?></td>
            <td style="text-align:center;"><?= $n['nilai_harian'] ?></td>
            <td style="text-align:center;"><?= $n['nilai_uts'] ?></td>
            <td style="text-align:center;"><?= $n['nilai_uas'] ?></td>
            <td style="text-align:center;font-weight:700;color:var(--green-700);"><?= $n['nilai_akhir'] ?></td>
            <td style="text-align:center;"><span class="pred pred-<?= substr($n['predikat'],0,1) ?>"><?= $n['predikat'] ?></span></td>
            <td style="font-size:11px;"><?= htmlspecialchars($n['deskripsi']??'') ?></td>
        </tr>
        <?php endforeach; ?>
        <tr style="background:var(--green-50);">
            <td colspan="5" style="text-align:right;font-weight:700;font-size:12px;padding:10px 12px;">Rata-rata Nilai:</td>
            <td style="text-align:center;font-weight:800;font-size:14px;color:var(--green-700);"><?= $countNilai ? round($totalNilai/$countNilai,1) : '-' ?></td>
            <td colspan="2"></td>
        </tr>
        </tbody>
    </table>

    <!-- Kehadiran -->
    <h3 style="font-size:14px;font-weight:700;color:var(--green-900);margin-bottom:10px;border-bottom:2px solid var(--green-700);padding-bottom:6px;">B. Ketidakhadiran</h3>
    <table style="font-size:12px;width:auto;margin-bottom:20px;">
        <thead><tr><th style="width:120px;">Keterangan</th><th style="width:80px;text-align:center;">Jumlah (Hari)</th></tr></thead>
        <tbody>
        <tr><td>Sakit</td><td style="text-align:center;"><?= $kehadiran['sakit'] ?? 0 ?></td></tr>
        <tr><td>Izin</td><td style="text-align:center;"><?= $kehadiran['izin'] ?? 0 ?></td></tr>
        <tr><td>Tanpa Keterangan (Alfa)</td><td style="text-align:center;"><?= $kehadiran['alpa'] ?? 0 ?></td></tr>
        </tbody>
    </table>

    <!-- Catatan -->
    <?php if ($catatan && $catatan['catatan_walikelas']): ?>
    <h3 style="font-size:14px;font-weight:700;color:var(--green-900);margin-bottom:8px;border-bottom:2px solid var(--green-700);padding-bottom:6px;">C. Catatan Wali Kelas</h3>
    <p style="font-size:12px;line-height:1.7;margin-bottom:20px;"><?= nl2br(htmlspecialchars($catatan['catatan_walikelas'])) ?></p>
    <?php endif; ?>

    <!-- Tanda Tangan -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:40px;margin-top:30px;font-size:12px;">
        <div style="text-align:center;">
            <p>Mengetahui,</p>
            <p>Orang Tua / Wali</p>
            <div style="height:60px;"></div>
            <p style="border-top:1px solid #000;display:inline-block;min-width:160px;padding-top:4px;">(.........................)</p>
        </div>
        <div style="text-align:center;">
            <p><?= $catatan['tanggal_rapor'] ? date('d F Y',strtotime($catatan['tanggal_rapor'])) : date('d F Y') ?></p>
            <p>Wali Kelas <?= htmlspecialchars($kelas['nama_kelas']) ?></p>
            <div style="height:60px;"></div>
            <p style="border-top:1px solid #000;display:inline-block;min-width:200px;padding-top:4px;font-weight:700;"><?= htmlspecialchars($wkUser['nama_lengkap']) ?></p>
        </div>
    </div>
</div>

<?php elseif ($selectedSiswa): ?>
<div class="card"><div class="card-body no-data"><i class="fas fa-inbox"></i><p>Belum ada nilai untuk siswa ini.</p></div></div>
<?php else: ?>
<div class="card"><div class="card-body no-data"><i class="fas fa-hand-pointer"></i><p>Pilih siswa untuk melihat rapor.</p></div></div>
<?php endif; ?>
</div><!-- end col rapor -->
</div><!-- end grid -->

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
