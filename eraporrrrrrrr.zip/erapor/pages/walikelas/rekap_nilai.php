<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('walikelas');
$db = getDB();
$pageTitle = 'Rekap Nilai Kelas';

$kelasList = getKelasWalikelas($_SESSION['user_id']);
$kelas = $kelasList[0] ?? null;

if (!$kelas) {
    require_once __DIR__ . '/../../includes/header.php';
    echo '<div class="card"><div class="card-body no-data"><i class="fas fa-exclamation-triangle" style="color:#f59e0b;"></i><p>Belum ditugaskan sebagai wali kelas.</p></div></div>';
    require_once __DIR__ . '/../../includes/footer.php'; exit;
}

// Ambil semua mapel yang dinilai di kelas ini
$mapelList = $db->query("
    SELECT DISTINCT m.id, m.kode, m.nama
    FROM mata_pelajaran m
    JOIN nilai n ON n.mapel_id=m.id
    WHERE n.kelas_id={$kelas['id']} AND n.tahun_ajaran='".TAHUN_AJARAN."' AND n.semester=".SEMESTER."
    ORDER BY m.nama
")->fetchAll();

$siswas = $db->query("SELECT * FROM siswa WHERE kelas_id={$kelas['id']} AND aktif=1 ORDER BY nama_lengkap")->fetchAll();

$rekapData = [];
foreach ($siswas as $s) {
    $stmt = $db->prepare("SELECT n.*, m.id as mid FROM nilai n JOIN mata_pelajaran m ON n.mapel_id=m.id WHERE n.siswa_id=? AND n.kelas_id=? AND n.tahun_ajaran=? AND n.semester=?");
    $stmt->execute([$s['id'], $kelas['id'], TAHUN_AJARAN, SEMESTER]);
    $nilaiRows = $stmt->fetchAll();
    $nilaiMap = [];
    foreach ($nilaiRows as $nr) $nilaiMap[$nr['mapel_id']] = $nr;
    $rekapData[$s['id']] = ['siswa' => $s, 'nilai' => $nilaiMap];
}

// Hitung ranking
$rataData = [];
foreach ($rekapData as $sid => $rd) {
    $arr = array_column($rd['nilai'],'nilai_akhir');
    $rataData[$sid] = count($arr) ? round(array_sum($arr)/count($arr),1) : 0;
}
arsort($rataData);
$ranking = array_keys($rataData);

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <div class="card-title">
            <i class="fas fa-table"></i>
            Rekap Nilai Kelas <?= htmlspecialchars($kelas['nama_kelas']) ?>
            <span class="badge badge-info" style="margin-left:8px;">TA <?= TAHUN_AJARAN ?> Sem. <?= SEMESTER ?></span>
        </div>
        <button onclick="window.print()" class="btn btn-secondary btn-sm"><i class="fas fa-print"></i> Cetak</button>
    </div>

    <?php if (empty($mapelList)): ?>
    <div class="card-body no-data"><i class="fas fa-inbox"></i><p>Belum ada nilai diinput untuk kelas ini.</p></div>
    <?php else: ?>
    <div class="table-responsive">
        <table>
            <thead>
                <tr style="background:linear-gradient(135deg,var(--green-900),var(--green-700));color:#fff;">
                    <th rowspan="2">No</th>
                    <th rowspan="2">Nama Siswa</th>
                    <?php foreach ($mapelList as $m): ?>
                    <th colspan="2" style="text-align:center;border-left:1px solid rgba(255,255,255,0.2);"><?= htmlspecialchars($m['kode']) ?></th>
                    <?php endforeach; ?>
                    <th rowspan="2" style="text-align:center;">Rata-rata</th>
                    <th rowspan="2" style="text-align:center;">Peringkat</th>
                </tr>
                <tr style="background:var(--green-800);color:#fff;">
                    <?php foreach ($mapelList as $m): ?>
                    <th style="font-size:10px;text-align:center;border-left:1px solid rgba(255,255,255,0.2);">Nilai</th>
                    <th style="font-size:10px;text-align:center;">Pred</th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
            <?php $no=1; foreach ($rekapData as $sid => $rd):
                $rank = array_search($sid, $ranking) + 1;
                $rata = $rataData[$sid];
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><strong><?= htmlspecialchars($rd['siswa']['nama_lengkap']) ?></strong></td>
                <?php foreach ($mapelList as $m):
                    $n = $rd['nilai'][$m['id']] ?? null;
                ?>
                <td style="text-align:center;border-left:1px solid #f0fdf4;"><?= $n ? $n['nilai_akhir'] : '-' ?></td>
                <td style="text-align:center;">
                    <?php if ($n && $n['predikat']): ?>
                    <span class="pred pred-<?= substr($n['predikat'],0,1) ?>"><?= $n['predikat'] ?></span>
                    <?php else: echo '-'; endif; ?>
                </td>
                <?php endforeach; ?>
                <td style="text-align:center;"><strong class="text-green"><?= $rata ?: '-' ?></strong></td>
                <td style="text-align:center;">
                    <?php if ($rank <= 3): ?>
                    <span class="badge badge-warning"><?= ['🥇','🥈','🥉'][$rank-1] ?> <?= $rank ?></span>
                    <?php else: echo $rank; endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div style="padding:10px 24px;font-size:11px;color:var(--text-muted);border-top:1px solid var(--border);">
        <?php $kodes=[];foreach($mapelList as $m)$kodes[]=$m['kode'].' = '.$m['nama'];echo implode(' | ',$kodes); ?>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
