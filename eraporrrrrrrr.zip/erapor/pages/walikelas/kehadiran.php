<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('walikelas');
$db = getDB();
$pageTitle = 'Kehadiran Siswa';

$kelasList = getKelasWalikelas($_SESSION['user_id']);
$kelas = $kelasList[0] ?? null;

if (!$kelas) {
    require_once __DIR__ . '/../../includes/header.php';
    echo '<div class="card"><div class="card-body no-data"><i class="fas fa-exclamation-triangle"></i><p>Belum ditugaskan sebagai wali kelas.</p></div></div>';
    require_once __DIR__ . '/../../includes/footer.php'; exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kehadiranPost = $_POST['kehadiran'] ?? [];
    foreach ($kehadiranPost as $siswa_id => $kh) {
        $sakit = (int)($kh['sakit'] ?? 0);
        $izin  = (int)($kh['izin'] ?? 0);
        $alpa  = (int)($kh['alpa'] ?? 0);
        $db->prepare("
            INSERT INTO kehadiran (siswa_id,kelas_id,tahun_ajaran,semester,sakit,izin,alpa)
            VALUES (?,?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE sakit=VALUES(sakit),izin=VALUES(izin),alpa=VALUES(alpa)
        ")->execute([$siswa_id,$kelas['id'],TAHUN_AJARAN,SEMESTER,$sakit,$izin,$alpa]);
    }
    flash('success','Data kehadiran berhasil disimpan!');
    header('Location: kehadiran.php'); exit;
}

$siswas = $db->query("SELECT * FROM siswa WHERE kelas_id={$kelas['id']} AND aktif=1 ORDER BY nama_lengkap")->fetchAll();

// Existing kehadiran
$kehadiranExisting = [];
$stmt = $db->prepare("SELECT * FROM kehadiran WHERE kelas_id=? AND tahun_ajaran=? AND semester=?");
$stmt->execute([$kelas['id'], TAHUN_AJARAN, SEMESTER]);
foreach ($stmt->fetchAll() as $kh) $kehadiranExisting[$kh['siswa_id']] = $kh;

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <div class="card-title">
            <i class="fas fa-calendar-check"></i>
            Kehadiran Siswa Kelas <?= htmlspecialchars($kelas['nama_kelas']) ?>
        </div>
        <span style="font-size:12px;color:var(--text-muted);">TA <?= TAHUN_AJARAN ?> | Semester <?= SEMESTER ?></span>
    </div>

    <div style="padding:12px 24px;background:var(--green-50);border-bottom:1px solid var(--border);font-size:13px;color:var(--green-800);">
        <i class="fas fa-info-circle"></i> Isikan total hari Sakit, Izin, dan Alfa selama satu semester.
    </div>

    <form method="POST">
        <div class="table-responsive">
            <table>
                <thead><tr>
                    <th>No</th><th>Nama Siswa</th>
                    <th style="text-align:center;">Sakit (hari)</th>
                    <th style="text-align:center;">Izin (hari)</th>
                    <th style="text-align:center;">Alfa (hari)</th>
                    <th style="text-align:center;">Total Tidak Hadir</th>
                </tr></thead>
                <tbody>
                <?php foreach ($siswas as $i => $s):
                    $kh = $kehadiranExisting[$s['id']] ?? null;
                    $sakit = $kh['sakit'] ?? 0;
                    $izin  = $kh['izin'] ?? 0;
                    $alpa  = $kh['alpa'] ?? 0;
                ?>
                <tr id="khrow-<?= $s['id'] ?>">
                    <td><?= $i+1 ?></td>
                    <td><strong><?= htmlspecialchars($s['nama_lengkap']) ?></strong></td>
                    <td style="text-align:center;">
                        <input type="number" name="kehadiran[<?= $s['id'] ?>][sakit]"
                               min="0" max="200" value="<?= $sakit ?>"
                               style="width:70px;text-align:center;"
                               onchange="hitungTotal(<?= $s['id'] ?>)">
                    </td>
                    <td style="text-align:center;">
                        <input type="number" name="kehadiran[<?= $s['id'] ?>][izin]"
                               min="0" max="200" value="<?= $izin ?>"
                               style="width:70px;text-align:center;"
                               onchange="hitungTotal(<?= $s['id'] ?>)">
                    </td>
                    <td style="text-align:center;">
                        <input type="number" name="kehadiran[<?= $s['id'] ?>][alpa]"
                               min="0" max="200" value="<?= $alpa ?>"
                               style="width:70px;text-align:center;"
                               onchange="hitungTotal(<?= $s['id'] ?>)">
                    </td>
                    <td style="text-align:center;" id="total-<?= $s['id'] ?>">
                        <strong><?= $sakit+$izin+$alpa ?></strong> hari
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div style="padding:18px 24px;border-top:1px solid var(--border);">
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan Kehadiran</button>
        </div>
    </form>
</div>

<script>
function hitungTotal(id) {
    const row = document.getElementById('khrow-'+id);
    const inputs = row.querySelectorAll('input[type=number]');
    let total = 0;
    inputs.forEach(i => total += parseInt(i.value)||0);
    document.getElementById('total-'+id).innerHTML = '<strong>'+total+'</strong> hari';
}
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
