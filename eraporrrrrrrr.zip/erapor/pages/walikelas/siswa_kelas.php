<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('walikelas');
$db = getDB();
$pageTitle = 'Siswa Kelas';

$kelasList = getKelasWalikelas($_SESSION['user_id']);
$kelas = $kelasList[0] ?? null;

if (!$kelas) {
    require_once __DIR__ . '/../../includes/header.php';
    echo '<div class="card"><div class="card-body no-data"><i class="fas fa-exclamation-triangle" style="color:#f59e0b;"></i><p>Anda belum ditugaskan sebagai wali kelas. Hubungi Admin.</p></div></div>';
    require_once __DIR__ . '/../../includes/footer.php';
    exit;
}

$search = $_GET['q'] ?? '';
$sql = "SELECT s.* FROM siswa s WHERE s.kelas_id=? AND s.aktif=1";
$params = [$kelas['id']];
if ($search) { $sql .= " AND (s.nama_lengkap LIKE ? OR s.nis LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
$sql .= " ORDER BY s.nama_lengkap";
$stmt = $db->prepare($sql); $stmt->execute($params);
$siswas = $stmt->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <div class="card-title">
            <i class="fas fa-user-group"></i> Siswa Kelas <?= htmlspecialchars($kelas['nama_kelas']) ?>
        </div>
        <span class="badge badge-info"><?= count($siswas) ?> siswa</span>
    </div>

    <div style="padding:14px 24px;border-bottom:1px solid var(--border);">
        <form method="GET" style="display:flex;gap:10px;">
            <input type="text" name="q" placeholder="Cari nama/NIS..." value="<?= htmlspecialchars($search) ?>" style="width:220px;">
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i></button>
            <?php if ($search): ?><a href="siswa_kelas.php" class="btn btn-secondary btn-sm"><i class="fas fa-times"></i></a><?php endif; ?>
        </form>
    </div>

    <div class="table-responsive">
        <table>
            <thead><tr>
                <th>No</th><th>NIS</th><th>NISN</th><th>Nama Lengkap</th>
                <th>L/P</th><th>Tempat, Tgl Lahir</th><th>Alamat</th>
            </tr></thead>
            <tbody>
            <?php if (empty($siswas)): ?>
            <tr><td colspan="7" class="no-data"><i class="fas fa-user-slash"></i> Tidak ada siswa</td></tr>
            <?php else: ?>
            <?php foreach ($siswas as $i => $s): ?>
            <tr>
                <td><?= $i+1 ?></td>
                <td><code><?= htmlspecialchars($s['nis']) ?></code></td>
                <td><small><?= htmlspecialchars($s['nisn']??'-') ?></small></td>
                <td><strong><?= htmlspecialchars($s['nama_lengkap']) ?></strong></td>
                <td><?= $s['jenis_kelamin']==='L' ? '👦 L' : '👧 P' ?></td>
                <td><?= htmlspecialchars($s['tempat_lahir']??'-') ?><?= $s['tanggal_lahir'] ? ', '.date('d/m/Y',strtotime($s['tanggal_lahir'])) : '' ?></td>
                <td style="max-width:200px;font-size:12px;"><?= htmlspecialchars($s['alamat']??'-') ?></td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
