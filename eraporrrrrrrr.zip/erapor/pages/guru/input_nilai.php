<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('guru');
$db = getDB();
$pageTitle = 'Input Nilai';
$guru_id = $_SESSION['user_id'];

// Ambil mapel yang diajar oleh guru ini
$stmtMapel = $db->prepare("
    SELECT gm.*, m.nama as mapel_nama, m.kode, k.nama_kelas, k.id as kelas_id
    FROM guru_mapel gm
    JOIN mata_pelajaran m ON gm.mapel_id=m.id
    JOIN kelas k ON gm.kelas_id=k.id
    WHERE gm.guru_id=? AND gm.tahun_ajaran=? AND gm.semester=?
    ORDER BY k.tingkat, m.nama
");
$stmtMapel->execute([$guru_id, TAHUN_AJARAN, SEMESTER]);
$mapelDiajar = $stmtMapel->fetchAll();

$selectedMapelId = (int)($_GET['mapel_id'] ?? ($mapelDiajar[0]['mapel_id'] ?? 0));
$selectedKelasId = (int)($_GET['kelas_id'] ?? ($mapelDiajar[0]['kelas_id'] ?? 0));

// Validasi: guru hanya bisa akses mapel yang dia ajar
$validPenugasan = null;
foreach ($mapelDiajar as $m) {
    if ($m['mapel_id'] == $selectedMapelId && $m['kelas_id'] == $selectedKelasId) {
        $validPenugasan = $m;
        break;
    }
}

if (!$validPenugasan && !empty($mapelDiajar)) {
    $validPenugasan = $mapelDiajar[0];
    $selectedMapelId = $validPenugasan['mapel_id'];
    $selectedKelasId = $validPenugasan['kelas_id'];
}

// Handle simpan nilai
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $validPenugasan) {
    $nilaiPost = $_POST['nilai'] ?? [];
    $saved = 0;
    foreach ($nilaiPost as $siswa_id => $ndata) {
        $harian = (float)($ndata['harian'] ?? 0);
        $uts    = (float)($ndata['uts'] ?? 0);
        $uas    = (float)($ndata['uas'] ?? 0);
        $akhir  = hitungNilaiAkhir($harian, $uts, $uas);
        $pred   = getPredikat($akhir);
        $desk   = trim($ndata['deskripsi'] ?? '');

        // Upsert
        $stmt = $db->prepare("
            INSERT INTO nilai (siswa_id,mapel_id,kelas_id,guru_id,tahun_ajaran,semester,nilai_harian,nilai_uts,nilai_uas,nilai_akhir,predikat,deskripsi)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE nilai_harian=VALUES(nilai_harian), nilai_uts=VALUES(nilai_uts),
                nilai_uas=VALUES(nilai_uas), nilai_akhir=VALUES(nilai_akhir),
                predikat=VALUES(predikat), deskripsi=VALUES(deskripsi)
        ");
        $stmt->execute([
            $siswa_id, $selectedMapelId, $selectedKelasId,
            $guru_id, TAHUN_AJARAN, SEMESTER,
            $harian, $uts, $uas, $akhir, $pred, $desk
        ]);
        $saved++;
    }
    flash('success', "Berhasil menyimpan $saved nilai siswa!");
    header("Location: input_nilai.php?mapel_id=$selectedMapelId&kelas_id=$selectedKelasId"); exit;
}

// Ambil daftar siswa di kelas
$siswaList = [];
$existingNilai = [];
if ($validPenugasan) {
    $stmtSiswa = $db->prepare("SELECT * FROM siswa WHERE kelas_id=? AND aktif=1 ORDER BY nama_lengkap");
    $stmtSiswa->execute([$selectedKelasId]);
    $siswaList = $stmtSiswa->fetchAll();

    $stmtNilai = $db->prepare("SELECT * FROM nilai WHERE mapel_id=? AND kelas_id=? AND guru_id=? AND tahun_ajaran=? AND semester=?");
    $stmtNilai->execute([$selectedMapelId, $selectedKelasId, $guru_id, TAHUN_AJARAN, SEMESTER]);
    foreach ($stmtNilai->fetchAll() as $n) {
        $existingNilai[$n['siswa_id']] = $n;
    }
}

require_once __DIR__ . '/../../includes/header.php';
?>

<!-- Pilih Mapel -->
<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-book-open"></i> Pilih Mata Pelajaran & Kelas</div>
    </div>
    <div style="padding:16px 24px;display:flex;gap:10px;flex-wrap:wrap;">
        <?php foreach ($mapelDiajar as $m): ?>
        <a href="input_nilai.php?mapel_id=<?= $m['mapel_id'] ?>&kelas_id=<?= $m['kelas_id'] ?>"
           class="btn <?= ($m['mapel_id']==$selectedMapelId && $m['kelas_id']==$selectedKelasId) ? 'btn-primary' : 'btn-secondary' ?>">
            <i class="fas fa-book"></i> <?= htmlspecialchars($m['kode']) ?> - <?= htmlspecialchars($m['nama_kelas']) ?>
        </a>
        <?php endforeach; ?>
        <?php if (empty($mapelDiajar)): ?>
        <p class="text-muted">Anda belum mendapat penugasan mengajar. Hubungi Admin.</p>
        <?php endif; ?>
    </div>
</div>

<!-- Form Input Nilai -->
<?php if ($validPenugasan && !empty($siswaList)): ?>
<div class="card">
    <div class="card-header">
        <div class="card-title">
            <i class="fas fa-pen-to-square"></i>
            Input Nilai &mdash; <?= htmlspecialchars($validPenugasan['mapel_nama']) ?>
            <span class="badge badge-info" style="margin-left:8px;"><?= htmlspecialchars($validPenugasan['nama_kelas']) ?></span>
        </div>
        <div style="font-size:12px;color:var(--text-muted);">
            TA <?= TAHUN_AJARAN ?> | Semester <?= SEMESTER ?> | <?= count($siswaList) ?> siswa
        </div>
    </div>

    <div style="padding:12px 24px;background:var(--green-50);border-bottom:1px solid var(--border);font-size:13px;color:var(--green-800);">
        <i class="fas fa-info-circle"></i>
        <strong>Rumus Nilai Akhir:</strong> (Harian × 40%) + (UTS × 30%) + (UAS × 30%). Rentang nilai: 0–100.
    </div>

    <form method="POST">
        <div class="table-responsive">
            <table class="nilai-table">
                <thead><tr>
                    <th>No</th>
                    <th>NIS</th>
                    <th>Nama Siswa</th>
                    <th style="text-align:center;">Nilai Harian (40%)</th>
                    <th style="text-align:center;">Nilai UTS (30%)</th>
                    <th style="text-align:center;">Nilai UAS (30%)</th>
                    <th style="text-align:center;">Nilai Akhir</th>
                    <th style="text-align:center;">Predikat</th>
                    <th>Deskripsi Kompetensi</th>
                </tr></thead>
                <tbody>
                <?php foreach ($siswaList as $i => $s):
                    $existing = $existingNilai[$s['id']] ?? null;
                    $h = $existing['nilai_harian'] ?? '';
                    $u = $existing['nilai_uts'] ?? '';
                    $a = $existing['nilai_uas'] ?? '';
                    $akhir = $existing['nilai_akhir'] ?? '';
                    $pred  = $existing['predikat'] ?? '';
                    $desk  = $existing['deskripsi'] ?? '';
                ?>
                <tr id="row-<?= $s['id'] ?>">
                    <td><?= $i+1 ?></td>
                    <td><small><?= htmlspecialchars($s['nis']) ?></small></td>
                    <td><strong><?= htmlspecialchars($s['nama_lengkap']) ?></strong></td>
                    <td style="text-align:center;">
                        <input type="number" name="nilai[<?= $s['id'] ?>][harian]"
                               min="0" max="100" step="0.5"
                               value="<?= $h ?>"
                               onchange="hitungAkhir(<?= $s['id'] ?>)"
                               class="harian-<?= $s['id'] ?>">
                    </td>
                    <td style="text-align:center;">
                        <input type="number" name="nilai[<?= $s['id'] ?>][uts]"
                               min="0" max="100" step="0.5"
                               value="<?= $u ?>"
                               onchange="hitungAkhir(<?= $s['id'] ?>)"
                               class="uts-<?= $s['id'] ?>">
                    </td>
                    <td style="text-align:center;">
                        <input type="number" name="nilai[<?= $s['id'] ?>][uas]"
                               min="0" max="100" step="0.5"
                               value="<?= $a ?>"
                               onchange="hitungAkhir(<?= $s['id'] ?>)"
                               class="uas-<?= $s['id'] ?>">
                    </td>
                    <td class="nilai-akhir-cell" style="text-align:center;" id="akhir-<?= $s['id'] ?>">
                        <?= $akhir ?: '-' ?>
                    </td>
                    <td style="text-align:center;" id="pred-<?= $s['id'] ?>">
                        <?php if ($pred): ?>
                        <span class="pred pred-<?= substr($pred,0,1) ?>"><?= $pred ?></span>
                        <?php else: echo '-'; endif; ?>
                    </td>
                    <td>
                        <input type="text" name="nilai[<?= $s['id'] ?>][deskripsi]"
                               placeholder="Deskripsi singkat..."
                               value="<?= htmlspecialchars($desk) ?>"
                               style="width:220px;">
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div style="padding:18px 24px;border-top:1px solid var(--border);">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> Simpan Semua Nilai
            </button>
        </div>
    </form>
</div>

<script>
function hitungAkhir(id) {
    const h = parseFloat(document.querySelector('.harian-'+id)?.value) || 0;
    const u = parseFloat(document.querySelector('.uts-'+id)?.value) || 0;
    const a = parseFloat(document.querySelector('.uas-'+id)?.value) || 0;
    const akhir = (h*0.4 + u*0.3 + a*0.3).toFixed(1);
    document.getElementById('akhir-'+id).textContent = akhir;
    const pred = getPredikat(parseFloat(akhir));
    const cls = pred.charAt(0);
    document.getElementById('pred-'+id).innerHTML = `<span class="pred pred-${cls}">${pred}</span>`;
}
function getPredikat(n) {
    if (n >= 93) return 'A+'; if (n >= 85) return 'A';
    if (n >= 80) return 'A-'; if (n >= 75) return 'B+';
    if (n >= 70) return 'B';  if (n >= 65) return 'B-';
    if (n >= 60) return 'C+'; if (n >= 55) return 'C';
    if (n >= 50) return 'C-'; return 'D';
}
</script>
<?php elseif ($validPenugasan): ?>
<div class="card"><div class="card-body no-data"><i class="fas fa-users-slash"></i><p>Tidak ada siswa di kelas ini.</p></div></div>
<?php endif; ?>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
