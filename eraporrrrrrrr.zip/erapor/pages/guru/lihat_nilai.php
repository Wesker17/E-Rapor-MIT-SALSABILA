<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('guru');
$db = getDB();
$pageTitle = 'Lihat Nilai';
$guru_id = $_SESSION['user_id'];

$mapelDiajar = $db->prepare("
    SELECT gm.*, m.nama as mapel_nama, m.kode, k.nama_kelas
    FROM guru_mapel gm
    JOIN mata_pelajaran m ON gm.mapel_id=m.id
    JOIN kelas k ON gm.kelas_id=k.id
    WHERE gm.guru_id=? AND gm.tahun_ajaran=? AND gm.semester=?
    ORDER BY k.tingkat, m.nama
");
$mapelDiajar->execute([$guru_id, TAHUN_AJARAN, SEMESTER]);
$mapelList = $mapelDiajar->fetchAll();

$selectedMapelId = (int)($_GET['mapel_id'] ?? ($mapelList[0]['mapel_id'] ?? 0));
$selectedKelasId = (int)($_GET['kelas_id'] ?? ($mapelList[0]['kelas_id'] ?? 0));

$validPenugasan = null;
foreach ($mapelList as $m) {
    if ($m['mapel_id'] == $selectedMapelId && $m['kelas_id'] == $selectedKelasId) {
        $validPenugasan = $m; break;
    }
}
if (!$validPenugasan && !empty($mapelList)) {
    $validPenugasan = $mapelList[0];
    $selectedMapelId = $validPenugasan['mapel_id'];
    $selectedKelasId = $validPenugasan['kelas_id'];
}

$nilaiList = [];
if ($validPenugasan) {
    $stmt = $db->prepare("
        SELECT n.*, s.nis, s.nama_lengkap, s.jenis_kelamin
        FROM nilai n
        JOIN siswa s ON n.siswa_id=s.id
        WHERE n.mapel_id=? AND n.kelas_id=? AND n.guru_id=? AND n.tahun_ajaran=? AND n.semester=?
        ORDER BY s.nama_lengkap
    ");
    $stmt->execute([$selectedMapelId, $selectedKelasId, $guru_id, TAHUN_AJARAN, SEMESTER]);
    $nilaiList = $stmt->fetchAll();
}

require_once __DIR__ . '/../../includes/header.php';
?>

<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;align-items:center;">
    <?php foreach ($mapelList as $m): ?>
    <a href="lihat_nilai.php?mapel_id=<?= $m['mapel_id'] ?>&kelas_id=<?= $m['kelas_id'] ?>"
       class="btn <?= ($m['mapel_id']==$selectedMapelId && $m['kelas_id']==$selectedKelasId) ? 'btn-primary' : 'btn-secondary' ?>">
        <?= htmlspecialchars($m['kode'].' - '.$m['nama_kelas']) ?>
    </a>
    <?php endforeach; ?>
</div>

<?php if ($validPenugasan): ?>
<div class="card">
    <div class="card-header">
        <div class="card-title">
            <i class="fas fa-table-list"></i>
            Nilai <?= htmlspecialchars($validPenugasan['mapel_nama']) ?> - Kelas <?= htmlspecialchars($validPenugasan['nama_kelas']) ?>
        </div>
        <div class="btn-group">
            <a href="input_nilai.php?mapel_id=<?= $selectedMapelId ?>&kelas_id=<?= $selectedKelasId ?>" class="btn btn-primary btn-sm">
                <i class="fas fa-pen"></i> Input/Edit Nilai
            </a>
        </div>
    </div>

    <?php if (!empty($nilaiList)): ?>
    <div style="padding:12px 24px;background:var(--green-50);border-bottom:1px solid var(--border);">
        <?php
        $nilaiAkhirAll = array_column($nilaiList,'nilai_akhir');
        $avg = round(array_sum($nilaiAkhirAll)/count($nilaiAkhirAll),1);
        $max = max($nilaiAkhirAll); $min = min($nilaiAkhirAll);
        ?>
        <span style="font-size:13px;color:var(--green-800);">
            <strong><?= count($nilaiList) ?></strong> siswa &nbsp;|&nbsp;
            Rata-rata: <strong><?= $avg ?></strong> &nbsp;|&nbsp;
            Tertinggi: <strong class="text-green"><?= $max ?></strong> &nbsp;|&nbsp;
            Terendah: <strong style="color:#dc2626;"><?= $min ?></strong>
        </span>
    </div>
    <?php endif; ?>

    <div class="table-responsive">
        <table>
            <thead><tr>
                <th>No</th><th>NIS</th><th>Nama Siswa</th><th>L/P</th>
                <th style="text-align:center;">Harian</th>
                <th style="text-align:center;">UTS</th>
                <th style="text-align:center;">UAS</th>
                <th style="text-align:center;">Nilai Akhir</th>
                <th style="text-align:center;">Predikat</th>
                <th>Deskripsi</th>
            </tr></thead>
            <tbody>
            <?php if (empty($nilaiList)): ?>
            <tr><td colspan="10" class="no-data"><i class="fas fa-inbox"></i> Belum ada nilai diinput</td></tr>
            <?php else: ?>
            <?php foreach ($nilaiList as $i => $n): ?>
            <tr>
                <td><?= $i+1 ?></td>
                <td><small><?= htmlspecialchars($n['nis']) ?></small></td>
                <td><strong><?= htmlspecialchars($n['nama_lengkap']) ?></strong></td>
                <td><?= $n['jenis_kelamin'] ?></td>
                <td style="text-align:center;"><?= $n['nilai_harian'] ?></td>
                <td style="text-align:center;"><?= $n['nilai_uts'] ?></td>
                <td style="text-align:center;"><?= $n['nilai_uas'] ?></td>
                <td style="text-align:center;"><strong class="text-green"><?= $n['nilai_akhir'] ?></strong></td>
                <td style="text-align:center;">
                    <span class="pred pred-<?= substr($n['predikat'],0,1) ?>"><?= $n['predikat'] ?></span>
                </td>
                <td style="font-size:12px;"><?= htmlspecialchars($n['deskripsi']??'-') ?></td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
