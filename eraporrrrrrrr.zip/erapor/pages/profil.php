<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
$db = getDB();
$pageTitle = 'Profil Saya';

$user = getCurrentUser();
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama    = trim($_POST['nama_lengkap']);
    $email   = trim($_POST['email']);
    $telepon = trim($_POST['telepon']);
    $pwLama  = $_POST['password_lama'] ?? '';
    $pwBaru  = $_POST['password_baru'] ?? '';
    $pwKonfirm = $_POST['password_konfirm'] ?? '';

    if (empty($nama)) $errors[] = 'Nama lengkap tidak boleh kosong.';

    // Update data dasar
    if (empty($errors)) {
        $db->prepare("UPDATE users SET nama_lengkap=?, email=?, telepon=? WHERE id=?")
           ->execute([$nama, $email, $telepon, $user['id']]);
        $_SESSION['nama'] = $nama;
        $success = true;

        // Ganti password jika diisi
        if (!empty($pwBaru)) {
            if (empty($pwLama)) {
                $errors[] = 'Masukkan password lama untuk mengubah password.';
                $success = false;
            } elseif (!password_verify($pwLama, $user['password'])) {
                $errors[] = 'Password lama tidak sesuai.';
                $success = false;
            } elseif (strlen($pwBaru) < 6) {
                $errors[] = 'Password baru minimal 6 karakter.';
                $success = false;
            } elseif ($pwBaru !== $pwKonfirm) {
                $errors[] = 'Konfirmasi password baru tidak cocok.';
                $success = false;
            } else {
                $db->prepare("UPDATE users SET password=? WHERE id=?")
                   ->execute([password_hash($pwBaru, PASSWORD_DEFAULT), $user['id']]);
            }
        }

        if ($success) {
            flash('success', 'Profil berhasil diperbarui!');
            header('Location: profil.php'); exit;
        }
    }

    // Reload user
    $stmt = $db->prepare("SELECT * FROM users WHERE id=?");
    $stmt->execute([$user['id']]);
    $user = $stmt->fetch();
}

$roleLabel = [
    'admin'     => ['Administrator', 'danger'],
    'guru'      => ['Guru', 'info'],
    'walikelas' => ['Wali Kelas', 'warning'],
    'ortu'      => ['Orang Tua / Wali', 'success'],
];
[$rl, $rc] = $roleLabel[$user['role']] ?? [$user['role'], 'info'];

require_once __DIR__ . '/../includes/header.php';
?>

<div style="display:grid;grid-template-columns:280px 1fr;gap:24px;align-items:start;">

    <!-- Kartu Profil -->
    <div class="card" style="text-align:center;">
        <div style="padding:32px 24px;">
            <div style="width:90px;height:90px;background:linear-gradient(135deg,var(--green-600),var(--green-900));border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:36px;font-weight:800;color:#fff;margin:0 auto 16px;box-shadow:0 4px 16px rgba(6,78,59,0.25);">
                <?= strtoupper(substr($user['nama_lengkap'],0,1)) ?>
            </div>
            <h2 style="font-size:17px;font-weight:700;color:var(--green-900);margin-bottom:6px;"><?= htmlspecialchars($user['nama_lengkap']) ?></h2>
            <span class="badge badge-<?= $rc ?>" style="font-size:12px;padding:4px 14px;"><?= $rl ?></span>
            <div style="margin-top:20px;font-size:13px;color:var(--text-muted);text-align:left;display:flex;flex-direction:column;gap:10px;">
                <div style="display:flex;align-items:center;gap:10px;">
                    <i class="fas fa-user" style="width:16px;color:var(--green-600);"></i>
                    <span><?= htmlspecialchars($user['username']) ?></span>
                </div>
                <?php if ($user['email']): ?>
                <div style="display:flex;align-items:center;gap:10px;">
                    <i class="fas fa-envelope" style="width:16px;color:var(--green-600);"></i>
                    <span><?= htmlspecialchars($user['email']) ?></span>
                </div>
                <?php endif; ?>
                <?php if ($user['telepon']): ?>
                <div style="display:flex;align-items:center;gap:10px;">
                    <i class="fas fa-phone" style="width:16px;color:var(--green-600);"></i>
                    <span><?= htmlspecialchars($user['telepon']) ?></span>
                </div>
                <?php endif; ?>
                <div style="display:flex;align-items:center;gap:10px;">
                    <i class="fas fa-circle" style="width:16px;color:<?= $user['aktif']?'var(--green-500)':'#ef4444' ?>;font-size:8px;"></i>
                    <span><?= $user['aktif'] ? 'Akun Aktif' : 'Akun Nonaktif' ?></span>
                </div>
                <div style="display:flex;align-items:center;gap:10px;">
                    <i class="fas fa-clock" style="width:16px;color:var(--green-600);"></i>
                    <span>Bergabung <?= date('d M Y', strtotime($user['created_at'])) ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Form Edit -->
    <div>
        <?php if (!empty($errors)): ?>
        <div class="alert alert-error" style="margin-bottom:16px;">
            <i class="fas fa-times-circle"></i>
            <div>
                <?php foreach ($errors as $e): ?>
                <div><?= htmlspecialchars($e) ?></div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <form method="POST">
            <!-- Data Diri -->
            <div class="card">
                <div class="card-header">
                    <div class="card-title"><i class="fas fa-user-edit"></i> Edit Data Diri</div>
                </div>
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Nama Lengkap *</label>
                            <input type="text" name="nama_lengkap" required
                                   value="<?= htmlspecialchars($user['nama_lengkap']) ?>">
                        </div>
                        <div class="form-group">
                            <label>Username <small style="color:var(--text-muted);">(tidak dapat diubah)</small></label>
                            <input type="text" value="<?= htmlspecialchars($user['username']) ?>" disabled
                                   style="background:#f8fafc;color:var(--text-muted);">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email"
                                   value="<?= htmlspecialchars($user['email']??'') ?>">
                        </div>
                        <div class="form-group">
                            <label>Nomor Telepon</label>
                            <input type="text" name="telepon"
                                   value="<?= htmlspecialchars($user['telepon']??'') ?>"
                                   placeholder="cth: 08123456789">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Ganti Password -->
            <div class="card">
                <div class="card-header">
                    <div class="card-title"><i class="fas fa-lock"></i> Ganti Password</div>
                    <span style="font-size:12px;color:var(--text-muted);">Kosongkan jika tidak ingin mengubah</span>
                </div>
                <div class="card-body">
                    <div class="form-row cols-3">
                        <div class="form-group">
                            <label>Password Lama</label>
                            <input type="password" name="password_lama" placeholder="Password saat ini">
                        </div>
                        <div class="form-group">
                            <label>Password Baru</label>
                            <input type="password" name="password_baru" placeholder="Min. 6 karakter">
                        </div>
                        <div class="form-group">
                            <label>Konfirmasi Password Baru</label>
                            <input type="password" name="password_konfirm" placeholder="Ulangi password baru">
                        </div>
                    </div>
                </div>
            </div>

            <div style="display:flex;gap:10px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Simpan Perubahan
                </button>
                <a href="<?= APP_URL ?>/dashboard.php" class="btn btn-secondary">
                    <i class="fas fa-home"></i> Kembali ke Dashboard
                </a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
