<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('ortu');
$db = getDB();
$pageTitle = 'Nilai Anak';

$stmtAnak = $db->prepare("
    SELECT s.*, k.nama_kelas
    FROM ortu_siswa os
    JOIN siswa s ON os.siswa_id=s.id
    LEFT JOIN kelas k ON s.kelas_id=k.id
    WHERE os.ortu_id=?
");
$stmtAnak->execute([$_SESSION['user_id']]);
$anakList = $stmtAnak->fetchAll();

require_once __DIR__ . '/../../includes/header.php';

if (empty($anakList)):
?>
<div class="card"><div class="card-body no-data">
    <i class="fas fa-user-slash" style="font-size:48px;color:var(--border);"></i>
    <p>Data anak Anda belum terhubung dengan sistem. Silakan hubungi Admin sekolah.</p>
</div></div>
<?php
    require_once __DIR__ . '/../../includes/footer.php'; exit;
endif;

foreach ($anakList as $anak):
    $stmtNilai = $db->prepare("
        SELECT n.*, m.nama as mapel_nama, m.kode, m.kelompok
        FROM nilai n JOIN mata_pelajaran m ON n.mapel_id=m.id
        WHERE n.siswa_id=? AND n.tahun_ajaran=? AND n.semester=?
        ORDER BY m.kelompok, m.nama
    ");
    $stmtNilai->execute([$anak['id'], TAHUN_AJARAN, SEMESTER]);
    $nilaiList = $stmtNilai->fetchAll();

    $stmtKH = $db->prepare("SELECT * FROM kehadiran WHERE siswa_id=? AND tahun_ajaran=? AND semester=?");
    $stmtKH->execute([$anak['id'], TAHUN_AJARAN, SEMESTER]);
    $kehadiran = $stmtKH->fetch();

    $avg = 0;
    if (!empty($nilaiList)) {
        $avg = round(array_sum(array_column($nilaiList,'nilai_akhir')) / count($nilaiList), 1);
    }
?>

<div class="card">
    <div class="card-header">
        <div class="card-title">
            <i class="fas fa-user-graduate"></i>
            <?= htmlspecialchars($anak['nama_lengkap']) ?>
            <span class="badge badge-info" style="margin-left:8px;">Kelas <?= htmlspecialchars($anak['nama_kelas']??'-') ?></span>
        </div>
        <div style="font-size:12px;color:var(--text-muted);">NIS: <?= htmlspecialchars($anak['nis']) ?> | TA <?= TAHUN_AJARAN ?> Sem. <?= SEMESTER ?></div>
    </div>

    <!-- Statistik -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:0;border-bottom:1px solid var(--border);">
        <div style="padding:18px 24px;text-align:center;border-right:1px solid var(--border);">
            <div style="font-size:28px;font-weight:800;color:var(--green-700);"><?= $avg ?: '-' ?></div>
            <div style="font-size:11px;color:var(--text-muted);">Rata-rata Nilai</div>
        </div>
        <div style="padding:18px 24px;text-align:center;border-right:1px solid var(--border);">
            <div style="font-size:28px;font-weight:800;color:var(--green-700);"><?= count($nilaiList) ?></div>
            <div style="font-size:11px;color:var(--text-muted);">Mata Pelajaran</div>
        </div>
        <div style="padding:18px 24px;text-align:center;border-right:1px solid var(--border);">
            <div style="font-size:28px;font-weight:800;color:#f59e0b;"><?= ($kehadiran['sakit']??0) ?></div>
            <div style="font-size:11px;color:var(--text-muted);">Hari Sakit</div>
        </div>
        <div style="padding:18px 24px;text-align:center;border-right:1px solid var(--border);">
            <div style="font-size:28px;font-weight:800;color:#3b82f6;"><?= ($kehadiran['izin']??0) ?></div>
            <div style="font-size:11px;color:var(--text-muted);">Hari Izin</div>
        </div>
        <div style="padding:18px 24px;text-align:center;">
            <div style="font-size:28px;font-weight:800;color:#ef4444;"><?= ($kehadiran['alpa']??0) ?></div>
            <div style="font-size:11px;color:var(--text-muted);">Hari Alfa</div>
        </div>
    </div>

    <!-- Tabel Nilai -->
    <div class="table-responsive">
        <table>
            <thead><tr>
                <th>No</th><th>Mata Pelajaran</th>
                <th style="text-align:center;">Nilai Harian</th>
                <th style="text-align:center;">UTS</th>
                <th style="text-align:center;">UAS</th>
                <th style="text-align:center;">Nilai Akhir</th>
                <th style="text-align:center;">Predikat</th>
                <th>Deskripsi</th>
            </tr></thead>
            <tbody>
            <?php if (empty($nilaiList)): ?>
            <tr><td colspan="8" class="no-data"><i class="fas fa-inbox"></i> Belum ada nilai</td></tr>
            <?php else:
                $no=1; $currentKelompok='';
                foreach ($nilaiList as $n):
                    if ($n['kelompok'] !== $currentKelompok):
                        $currentKelompok = $n['kelompok'];
                        $label = ['A'=>'Kelompok A - Umum','B'=>'Kelompok B - Pilihan','C'=>'Kelompok C - Muatan Lokal'][$currentKelompok];
            ?>
            <tr><td colspan="8" style="background:var(--green-50);font-weight:700;font-size:11px;color:var(--green-800);padding:8px 16px;"><?= $label ?></td></tr>
            <?php endif; ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><strong><?= htmlspecialchars($n['mapel_nama']) ?></strong> <small style="color:var(--text-muted);">(<?= $n['kode'] ?>)</small></td>
                <td style="text-align:center;"><?= $n['nilai_harian'] ?></td>
                <td style="text-align:center;"><?= $n['nilai_uts'] ?></td>
                <td style="text-align:center;"><?= $n['nilai_uas'] ?></td>
                <td style="text-align:center;font-weight:800;font-size:15px;color:var(--green-700);"><?= $n['nilai_akhir'] ?></td>
                <td style="text-align:center;"><span class="pred pred-<?= substr($n['predikat'],0,1) ?>"><?= $n['predikat'] ?></span></td>
                <td style="font-size:12px;color:var(--text-muted);"><?= htmlspecialchars($n['deskripsi']??'-') ?></td>
            </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php endforeach; ?>

<!-- Keterangan Predikat -->
<div class="card">
    <div class="card-header"><div class="card-title"><i class="fas fa-info-circle"></i> Keterangan Predikat</div></div>
    <div style="padding:16px 24px;display:flex;gap:10px;flex-wrap:wrap;font-size:13px;">
        <span class="pred pred-A">A+ ≥ 93</span>
        <span class="pred pred-A">A ≥ 85</span>
        <span class="pred pred-A">A- ≥ 80</span>
        <span class="pred pred-B">B+ ≥ 75</span>
        <span class="pred pred-B">B ≥ 70</span>
        <span class="pred pred-B">B- ≥ 65</span>
        <span class="pred pred-C">C+ ≥ 60</span>
        <span class="pred pred-C">C ≥ 55</span>
        <span class="pred pred-C">C- ≥ 50</span>
        <span class="pred pred-D">D &lt; 50</span>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
