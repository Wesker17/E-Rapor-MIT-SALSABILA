<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('ortu');
$db = getDB();
$pageTitle = 'Rapor Anak';

// Ambil data anak yang terhubung ke ortu ini
$stmtAnak = $db->prepare("
    SELECT s.*, k.nama_kelas, k.id as kelas_id, u.nama_lengkap as wk_nama
    FROM ortu_siswa os
    JOIN siswa s ON os.siswa_id = s.id
    LEFT JOIN kelas k ON s.kelas_id = k.id
    LEFT JOIN users u ON k.walikelas_id = u.id
    WHERE os.ortu_id = ?
    LIMIT 1
");
$stmtAnak->execute([$_SESSION['user_id']]);
$anak = $stmtAnak->fetch();

require_once __DIR__ . '/../../includes/header.php';

if (!$anak):
?>
<div class="card">
    <div class="card-body no-data">
        <i class="fas fa-user-slash" style="font-size:52px;color:var(--border);display:block;margin-bottom:14px;"></i>
        <p>Data anak Anda belum terhubung. Silakan hubungi Admin sekolah.</p>
    </div>
</div>
<?php
    require_once __DIR__ . '/../../includes/footer.php';
    exit;
endif;

// Ambil nilai
$stmtNilai = $db->prepare("
    SELECT n.*, m.nama as mapel_nama, m.kode, m.kelompok
    FROM nilai n
    JOIN mata_pelajaran m ON n.mapel_id = m.id
    WHERE n.siswa_id = ? AND n.tahun_ajaran = ? AND n.semester = ?
    ORDER BY m.kelompok, m.nama
");
$stmtNilai->execute([$anak['id'], TAHUN_AJARAN, SEMESTER]);
$nilaiList = $stmtNilai->fetchAll();

// Kehadiran
$stmtKH = $db->prepare("SELECT * FROM kehadiran WHERE siswa_id=? AND tahun_ajaran=? AND semester=?");
$stmtKH->execute([$anak['id'], TAHUN_AJARAN, SEMESTER]);
$kehadiran = $stmtKH->fetch();

// Catatan walikelas
$stmtCatatan = $db->prepare("SELECT * FROM catatan_rapor WHERE siswa_id=? AND kelas_id=? AND tahun_ajaran=? AND semester=?");
$stmtCatatan->execute([$anak['id'], $anak['kelas_id'], TAHUN_AJARAN, SEMESTER]);
$catatan = $stmtCatatan->fetch();

// Hitung rata-rata & ranking
$avg = 0;
if (!empty($nilaiList)) {
    $avg = round(array_sum(array_column($nilaiList,'nilai_akhir')) / count($nilaiList), 1);
}

// Ranking di kelas
$stmtRank = $db->prepare("
    SELECT siswa_id, ROUND(AVG(nilai_akhir),1) as rata
    FROM nilai
    WHERE kelas_id=? AND tahun_ajaran=? AND semester=?
    GROUP BY siswa_id
    ORDER BY rata DESC
");
$stmtRank->execute([$anak['kelas_id'], TAHUN_AJARAN, SEMESTER]);
$rankList = $stmtRank->fetchAll(PDO::FETCH_COLUMN|PDO::FETCH_UNIQUE, 0);
$ranking  = array_search($anak['id'], array_keys($rankList)) + 1;
?>

<!-- Tombol Cetak (tidak muncul saat print) -->
<div class="no-print" style="margin-bottom:20px;display:flex;gap:10px;">
    <button onclick="window.print()" class="btn btn-gold">
        <i class="fas fa-print"></i> Cetak / Simpan PDF
    </button>
    <a href="nilai_anak.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Kembali
    </a>
</div>

<!-- ============ RAPOR ============ -->
<div class="card" style="max-width:820px;margin:0 auto;" id="rapor-cetak">
    <!-- KOP RAPOR -->
    <div style="padding:28px 32px 18px;border-bottom:3px double var(--green-700);">
        <div style="display:flex;align-items:center;gap:20px;margin-bottom:16px;">
            <!-- Logo -->
            <div style="width:80px;height:80px;background:linear-gradient(135deg,var(--green-700),var(--green-900));border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:32px;color:var(--gold);flex-shrink:0;box-shadow:0 4px 14px rgba(6,78,59,0.3);">
                <i class="fas fa-graduation-cap"></i>
            </div>
            <!-- Identitas Sekolah -->
            <div style="flex:1;text-align:center;">
                <div style="font-size:11px;text-transform:uppercase;letter-spacing:2px;color:var(--text-muted);margin-bottom:2px;">Yayasan Pendidikan Islam Salsabila</div>
                <div style="font-family:'Amiri',serif;font-size:26px;font-weight:700;color:var(--green-900);line-height:1.1;">SD MIT Salsabila</div>
                <div style="font-size:12px;color:var(--text-muted);margin-top:4px;">
                    <i class="fas fa-map-marker-alt"></i> Jl. Pendidikan No. 1 &nbsp;|&nbsp;
                    <i class="fas fa-phone"></i> (021) 123-4567 &nbsp;|&nbsp;
                    <i class="fas fa-envelope"></i> info@mitsalsabila.sch.id
                </div>
            </div>
        </div>
        <div style="text-align:center;margin-top:10px;">
            <div style="display:inline-block;background:var(--green-900);color:#fff;padding:8px 32px;font-size:15px;font-weight:700;letter-spacing:3px;border-radius:4px;">
                LAPORAN HASIL BELAJAR SISWA
            </div>
            <div style="font-size:12px;margin-top:8px;color:var(--text-muted);">
                Tahun Pelajaran <?= TAHUN_AJARAN ?> &nbsp;&mdash;&nbsp; Semester <?= SEMESTER == 1 ? 'Ganjil' : 'Genap' ?>
            </div>
        </div>
    </div>

    <!-- DATA SISWA -->
    <div style="padding:20px 32px;border-bottom:1px solid var(--border);background:var(--green-50);">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px 32px;font-size:13px;">
            <div style="display:flex;gap:8px;">
                <span style="color:var(--text-muted);min-width:110px;">Nama Siswa</span>
                <span>: <strong><?= htmlspecialchars($anak['nama_lengkap']) ?></strong></span>
            </div>
            <div style="display:flex;gap:8px;">
                <span style="color:var(--text-muted);min-width:110px;">Kelas</span>
                <span>: <strong><?= htmlspecialchars($anak['nama_kelas']??'-') ?></strong></span>
            </div>
            <div style="display:flex;gap:8px;">
                <span style="color:var(--text-muted);min-width:110px;">NIS / NISN</span>
                <span>: <?= htmlspecialchars($anak['nis']) ?> / <?= htmlspecialchars($anak['nisn']??'-') ?></span>
            </div>
            <div style="display:flex;gap:8px;">
                <span style="color:var(--text-muted);min-width:110px;">Wali Kelas</span>
                <span>: <?= htmlspecialchars($anak['wk_nama']??'-') ?></span>
            </div>
            <div style="display:flex;gap:8px;">
                <span style="color:var(--text-muted);min-width:110px;">Jenis Kelamin</span>
                <span>: <?= $anak['jenis_kelamin']==='L' ? 'Laki-laki' : 'Perempuan' ?></span>
            </div>
            <div style="display:flex;gap:8px;">
                <span style="color:var(--text-muted);min-width:110px;">Rata-rata</span>
                <span>: <strong style="color:var(--green-700);font-size:15px;"><?= $avg ?: '-' ?></strong>
                <?php if ($ranking > 0): ?>
                &nbsp;<span class="badge badge-warning">Peringkat <?= $ranking ?></span>
                <?php endif; ?>
                </span>
            </div>
            <?php if ($anak['tempat_lahir']): ?>
            <div style="display:flex;gap:8px;">
                <span style="color:var(--text-muted);min-width:110px;">Tempat, Tgl Lahir</span>
                <span>: <?= htmlspecialchars($anak['tempat_lahir']) ?><?= $anak['tanggal_lahir'] ? ', '.date('d F Y',strtotime($anak['tanggal_lahir'])) : '' ?></span>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div style="padding:24px 32px;">

        <!-- CAPAIAN HASIL BELAJAR -->
        <h3 style="font-size:13px;font-weight:700;color:var(--green-900);margin-bottom:12px;display:flex;align-items:center;gap:8px;">
            <span style="display:inline-flex;width:22px;height:22px;background:var(--green-700);color:#fff;border-radius:50%;align-items:center;justify-content:center;font-size:11px;">A</span>
            Capaian Hasil Belajar
        </h3>

        <?php if (empty($nilaiList)): ?>
        <div style="text-align:center;padding:24px;color:var(--text-muted);font-size:13px;">
            <i class="fas fa-inbox" style="font-size:32px;display:block;margin-bottom:8px;"></i>
            Nilai belum tersedia
        </div>
        <?php else: ?>
        <table style="font-size:12px;margin-bottom:24px;width:100%;">
            <thead>
                <tr style="background:linear-gradient(135deg,var(--green-900),var(--green-700));color:#fff;">
                    <th style="padding:8px 10px;width:32px;text-align:center;">No</th>
                    <th style="padding:8px 10px;">Mata Pelajaran</th>
                    <th style="padding:8px 10px;text-align:center;width:65px;">Nilai Harian</th>
                    <th style="padding:8px 10px;text-align:center;width:55px;">UTS</th>
                    <th style="padding:8px 10px;text-align:center;width:55px;">UAS</th>
                    <th style="padding:8px 10px;text-align:center;width:65px;">Nilai Akhir</th>
                    <th style="padding:8px 10px;text-align:center;width:58px;">Predikat</th>
                    <th style="padding:8px 10px;">Deskripsi Kompetensi</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $no = 1;
            $currentKelompok = '';
            foreach ($nilaiList as $n):
                if ($n['kelompok'] !== $currentKelompok):
                    $currentKelompok = $n['kelompok'];
                    $label = [
                        'A' => 'Kelompok A &mdash; Muatan Umum / Wajib',
                        'B' => 'Kelompok B &mdash; Pengembangan Diri',
                        'C' => 'Kelompok C &mdash; Muatan Lokal',
                    ][$currentKelompok] ?? 'Kelompok '.$currentKelompok;
            ?>
            <tr>
                <td colspan="8" style="background:var(--green-100);color:var(--green-900);font-weight:700;font-size:11px;padding:6px 10px;border-top:2px solid var(--green-300);">
                    <?= $label ?>
                </td>
            </tr>
            <?php endif; ?>
            <tr style="border-bottom:1px solid #f0fdf4;">
                <td style="text-align:center;padding:8px 10px;"><?= $no++ ?></td>
                <td style="padding:8px 10px;font-weight:500;"><?= htmlspecialchars($n['mapel_nama']) ?></td>
                <td style="text-align:center;padding:8px 10px;"><?= $n['nilai_harian'] ?></td>
                <td style="text-align:center;padding:8px 10px;"><?= $n['nilai_uts'] ?></td>
                <td style="text-align:center;padding:8px 10px;"><?= $n['nilai_uas'] ?></td>
                <td style="text-align:center;padding:8px 10px;font-weight:800;font-size:14px;color:var(--green-700);"><?= $n['nilai_akhir'] ?></td>
                <td style="text-align:center;padding:8px 10px;">
                    <span class="pred pred-<?= substr($n['predikat'],0,1) ?>"><?= $n['predikat'] ?></span>
                </td>
                <td style="padding:8px 10px;font-size:11px;color:var(--text-muted);"><?= htmlspecialchars($n['deskripsi']??'') ?></td>
            </tr>
            <?php endforeach; ?>
            <!-- Baris rata-rata -->
            <tr style="background:var(--green-50);border-top:2px solid var(--green-300);">
                <td colspan="5" style="text-align:right;padding:10px;font-weight:700;">Rata-rata Nilai Keseluruhan :</td>
                <td style="text-align:center;padding:10px;font-weight:900;font-size:16px;color:var(--green-700);"><?= $avg ?></td>
                <td colspan="2" style="padding:10px;">
                    <span class="pred pred-<?= substr(getPredikat($avg),0,1) ?>"><?= getPredikat($avg) ?></span>
                </td>
            </tr>
            </tbody>
        </table>
        <?php endif; ?>

        <!-- KETIDAKHADIRAN -->
        <h3 style="font-size:13px;font-weight:700;color:var(--green-900);margin-bottom:12px;display:flex;align-items:center;gap:8px;">
            <span style="display:inline-flex;width:22px;height:22px;background:var(--green-700);color:#fff;border-radius:50%;align-items:center;justify-content:center;font-size:11px;">B</span>
            Ketidakhadiran
        </h3>
        <table style="font-size:12px;width:auto;margin-bottom:24px;min-width:300px;">
            <thead>
                <tr style="background:var(--green-800);color:#fff;">
                    <th style="padding:8px 20px;width:180px;">Keterangan</th>
                    <th style="padding:8px 20px;text-align:center;">Jumlah (Hari)</th>
                </tr>
            </thead>
            <tbody>
                <tr style="border-bottom:1px solid #f0fdf4;">
                    <td style="padding:8px 20px;">Sakit</td>
                    <td style="text-align:center;padding:8px 20px;"><?= $kehadiran['sakit'] ?? 0 ?></td>
                </tr>
                <tr style="border-bottom:1px solid #f0fdf4;">
                    <td style="padding:8px 20px;">Izin</td>
                    <td style="text-align:center;padding:8px 20px;"><?= $kehadiran['izin'] ?? 0 ?></td>
                </tr>
                <tr>
                    <td style="padding:8px 20px;">Tanpa Keterangan (Alfa)</td>
                    <td style="text-align:center;padding:8px 20px;"><?= $kehadiran['alpa'] ?? 0 ?></td>
                </tr>
            </tbody>
        </table>

        <!-- CATATAN WALIKELAS -->
        <?php if ($catatan && !empty($catatan['catatan_walikelas'])): ?>
        <h3 style="font-size:13px;font-weight:700;color:var(--green-900);margin-bottom:10px;display:flex;align-items:center;gap:8px;">
            <span style="display:inline-flex;width:22px;height:22px;background:var(--green-700);color:#fff;border-radius:50%;align-items:center;justify-content:center;font-size:11px;">C</span>
            Catatan Wali Kelas
        </h3>
        <div style="background:var(--green-50);border-left:4px solid var(--green-500);padding:14px 18px;border-radius:0 8px 8px 0;margin-bottom:24px;font-size:13px;line-height:1.8;color:var(--text);">
            <?= nl2br(htmlspecialchars($catatan['catatan_walikelas'])) ?>
        </div>
        <?php endif; ?>

        <!-- KETERANGAN PREDIKAT -->
        <h3 style="font-size:13px;font-weight:700;color:var(--green-900);margin-bottom:10px;display:flex;align-items:center;gap:8px;">
            <span style="display:inline-flex;width:22px;height:22px;background:var(--green-700);color:#fff;border-radius:50%;align-items:center;justify-content:center;font-size:11px;">D</span>
            Keterangan Predikat
        </h3>
        <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:30px;font-size:12px;">
            <?php
            $preds = [
                'A+' => ['≥ 93', 'A'],
                'A'  => ['≥ 85', 'A'],
                'A-' => ['≥ 80', 'A'],
                'B+' => ['≥ 75', 'B'],
                'B'  => ['≥ 70', 'B'],
                'B-' => ['≥ 65', 'B'],
                'C+' => ['≥ 60', 'C'],
                'C'  => ['≥ 55', 'C'],
                'C-' => ['≥ 50', 'C'],
                'D'  => ['< 50', 'D'],
            ];
            foreach ($preds as $p => [$range, $cls]): ?>
            <span class="pred pred-<?= $cls ?>"><?= $p ?> (<?= $range ?>)</span>
            <?php endforeach; ?>
        </div>

        <!-- TANDA TANGAN -->
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:24px;font-size:12px;text-align:center;margin-top:10px;">
            <div>
                <p style="margin-bottom:4px;">Mengetahui,</p>
                <p>Kepala Sekolah</p>
                <div style="height:64px;"></div>
                <p style="border-top:1px solid #000;padding-top:4px;display:inline-block;min-width:160px;">
                    <strong>(.........................)</strong>
                </p>
            </div>
            <div>
                <p style="margin-bottom:4px;">Wali Kelas <?= htmlspecialchars($anak['nama_kelas']??'') ?></p>
                <p>&nbsp;</p>
                <div style="height:64px;"></div>
                <p style="border-top:1px solid #000;padding-top:4px;display:inline-block;min-width:160px;">
                    <strong><?= htmlspecialchars($anak['wk_nama']??'(..........................)') ?></strong>
                </p>
            </div>
            <div>
                <p style="margin-bottom:4px;">
                    <?= $catatan && $catatan['tanggal_rapor']
                        ? date('d F Y', strtotime($catatan['tanggal_rapor']))
                        : date('d F Y') ?>
                </p>
                <p>Orang Tua / Wali</p>
                <div style="height:64px;"></div>
                <p style="border-top:1px solid #000;padding-top:4px;display:inline-block;min-width:160px;">
                    <strong><?= htmlspecialchars($_SESSION['nama']) ?></strong>
                </p>
            </div>
        </div>

    </div><!-- end padding -->
</div><!-- end rapor card -->

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
