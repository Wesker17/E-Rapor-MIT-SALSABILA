<?php
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) {
    header('Location: ' . APP_URL . '/dashboard.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    if (empty($username) || empty($password)) {
        $error = 'Username dan password wajib diisi.';
    } elseif (!login($username, $password)) {
        $error = 'Username atau password salah, atau akun tidak aktif.';
    } else {
        header('Location: ' . APP_URL . '/dashboard.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - E-Rapor SD MIT Salsabila</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Amiri:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body class="login-page">
<div class="login-card">
    <div class="login-logo">
        <div class="login-logo-icon">
            <i class="fas fa-graduation-cap"></i>
        </div>
        <h1>MIT Salsabila</h1>
        <p>Sistem Informasi E-Rapor Digital</p>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-error" style="margin:0 0 18px;">
        <i class="fas fa-times-circle"></i> <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label><i class="fas fa-user"></i> Username</label>
            <input type="text" name="username" placeholder="Masukkan username"
                   value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required autofocus>
        </div>
        <div class="form-group">
            <label><i class="fas fa-lock"></i> Password</label>
            <div style="position:relative;">
                <input type="password" name="password" id="passwordInput" placeholder="Masukkan password" required>
                <button type="button" onclick="togglePwd()" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:#94a3b8;font-size:14px;">
                    <i class="fas fa-eye" id="eyeIcon"></i>
                </button>
            </div>
        </div>
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-sign-in-alt"></i> Masuk
        </button>
    </form>

    <div class="login-hint">
        <strong>Akun Demo:</strong> admin / guru1 / wk1 / ortu1 &nbsp;|&nbsp; Password: <code>password</code>
    </div>
</div>

<script>
function togglePwd() {
    const inp = document.getElementById('passwordInput');
    const ico = document.getElementById('eyeIcon');
    if (inp.type === 'password') {
        inp.type = 'text'; ico.className = 'fas fa-eye-slash';
    } else {
        inp.type = 'password'; ico.className = 'fas fa-eye';
    }
}
</script>
</body>
</html>
