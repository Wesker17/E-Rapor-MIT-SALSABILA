-- =============================================
-- DATABASE E-RAPOR SD MIT SALSABILA
-- =============================================

CREATE DATABASE IF NOT EXISTS erapor_salsabila CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE erapor_salsabila;

-- Tabel Users (semua role)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    nama_lengkap VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    telepon VARCHAR(20),
    role ENUM('admin','guru','walikelas','ortu') NOT NULL,
    foto VARCHAR(255) DEFAULT NULL,
    aktif TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabel Kelas
CREATE TABLE kelas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_kelas VARCHAR(20) NOT NULL,
    tingkat INT NOT NULL COMMENT '1-6',
    tahun_ajaran VARCHAR(10) NOT NULL,
    walikelas_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (walikelas_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Tabel Siswa
CREATE TABLE siswa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nis VARCHAR(20) UNIQUE NOT NULL,
    nisn VARCHAR(20) UNIQUE,
    nama_lengkap VARCHAR(100) NOT NULL,
    jenis_kelamin ENUM('L','P') NOT NULL,
    tempat_lahir VARCHAR(50),
    tanggal_lahir DATE,
    alamat TEXT,
    kelas_id INT,
    foto VARCHAR(255) DEFAULT NULL,
    aktif TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (kelas_id) REFERENCES kelas(id) ON DELETE SET NULL
);

-- Relasi Ortu - Siswa
CREATE TABLE ortu_siswa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ortu_id INT NOT NULL,
    siswa_id INT NOT NULL,
    hubungan ENUM('Ayah','Ibu','Wali') DEFAULT 'Wali',
    FOREIGN KEY (ortu_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE CASCADE,
    UNIQUE KEY unique_ortu_siswa (ortu_id, siswa_id)
);

-- Tabel Mata Pelajaran
CREATE TABLE mata_pelajaran (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(10) UNIQUE NOT NULL,
    nama VARCHAR(100) NOT NULL,
    kelompok ENUM('A','B','C') DEFAULT 'A' COMMENT 'A=Umum, B=Kejuruan, C=Muatan Lokal',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Relasi Guru - Mata Pelajaran - Kelas
CREATE TABLE guru_mapel (
    id INT AUTO_INCREMENT PRIMARY KEY,
    guru_id INT NOT NULL,
    mapel_id INT NOT NULL,
    kelas_id INT NOT NULL,
    tahun_ajaran VARCHAR(10) NOT NULL,
    semester TINYINT NOT NULL DEFAULT 1,
    FOREIGN KEY (guru_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (mapel_id) REFERENCES mata_pelajaran(id) ON DELETE CASCADE,
    FOREIGN KEY (kelas_id) REFERENCES kelas(id) ON DELETE CASCADE,
    UNIQUE KEY unique_guru_mapel (guru_id, mapel_id, kelas_id, tahun_ajaran, semester)
);

-- Tabel Nilai
CREATE TABLE nilai (
    id INT AUTO_INCREMENT PRIMARY KEY,
    siswa_id INT NOT NULL,
    mapel_id INT NOT NULL,
    kelas_id INT NOT NULL,
    guru_id INT NOT NULL,
    tahun_ajaran VARCHAR(10) NOT NULL,
    semester TINYINT NOT NULL DEFAULT 1,
    nilai_harian DECIMAL(5,2) DEFAULT 0,
    nilai_uts DECIMAL(5,2) DEFAULT 0,
    nilai_uas DECIMAL(5,2) DEFAULT 0,
    nilai_akhir DECIMAL(5,2) DEFAULT 0,
    predikat CHAR(2) DEFAULT NULL,
    deskripsi TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE CASCADE,
    FOREIGN KEY (mapel_id) REFERENCES mata_pelajaran(id) ON DELETE CASCADE,
    FOREIGN KEY (kelas_id) REFERENCES kelas(id) ON DELETE CASCADE,
    FOREIGN KEY (guru_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_nilai (siswa_id, mapel_id, tahun_ajaran, semester)
);

-- Tabel Kehadiran
CREATE TABLE kehadiran (
    id INT AUTO_INCREMENT PRIMARY KEY,
    siswa_id INT NOT NULL,
    kelas_id INT NOT NULL,
    tahun_ajaran VARCHAR(10) NOT NULL,
    semester TINYINT NOT NULL,
    sakit INT DEFAULT 0,
    izin INT DEFAULT 0,
    alpa INT DEFAULT 0,
    FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE CASCADE,
    FOREIGN KEY (kelas_id) REFERENCES kelas(id) ON DELETE CASCADE,
    UNIQUE KEY unique_kehadiran (siswa_id, tahun_ajaran, semester)
);

-- Tabel Catatan Walikelas (untuk rapor)
CREATE TABLE catatan_rapor (
    id INT AUTO_INCREMENT PRIMARY KEY,
    siswa_id INT NOT NULL,
    kelas_id INT NOT NULL,
    tahun_ajaran VARCHAR(10) NOT NULL,
    semester TINYINT NOT NULL,
    catatan_walikelas TEXT,
    tanggal_rapor DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE CASCADE,
    FOREIGN KEY (kelas_id) REFERENCES kelas(id) ON DELETE CASCADE,
    UNIQUE KEY unique_catatan (siswa_id, tahun_ajaran, semester)
);

-- =============================================
-- DATA AWAL (SEED DATA)
-- =============================================

-- Admin
INSERT INTO users (username, password, nama_lengkap, email, role) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', 'admin@mitsalsabila.sch.id', 'admin'),
('guru1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Ibu Sari Dewi', 'sari@mitsalsabila.sch.id', 'guru'),
('guru2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Bapak Ahmad Fauzi', 'ahmad@mitsalsabila.sch.id', 'guru'),
('guru3', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Ibu Rahma Putri', 'rahma@mitsalsabila.sch.id', 'guru'),
('wk1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Ibu Nila Sari', 'nila@mitsalsabila.sch.id', 'walikelas'),
('wk2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Bapak Hendra', 'hendra@mitsalsabila.sch.id', 'walikelas'),
('ortu1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Bapak Budi Santoso', 'budi@gmail.com', 'ortu'),
('ortu2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Ibu Ani Wijaya', 'ani@gmail.com', 'ortu');
-- Password semua: password

-- Kelas
INSERT INTO kelas (nama_kelas, tingkat, tahun_ajaran, walikelas_id) VALUES
('1A', 1, '2024/2025', 5),
('2A', 2, '2024/2025', 6),
('3A', 3, '2024/2025', NULL),
('4A', 4, '2024/2025', NULL),
('5A', 5, '2024/2025', NULL),
('6A', 6, '2024/2025', NULL);

-- Siswa
INSERT INTO siswa (nis, nisn, nama_lengkap, jenis_kelamin, tempat_lahir, tanggal_lahir, kelas_id) VALUES
('2024001', '1234567890', 'Ahmad Rizki Maulana', 'L', 'Jakarta', '2017-03-15', 1),
('2024002', '1234567891', 'Siti Fatimah', 'P', 'Bekasi', '2017-05-20', 1),
('2024003', '1234567892', 'Budi Prasetyo', 'L', 'Depok', '2017-01-10', 1),
('2023001', '1234567893', 'Dewi Rahayu', 'P', 'Jakarta', '2016-07-25', 2),
('2023002', '1234567894', 'Faisal Hakim', 'L', 'Bogor', '2016-09-12', 2);

-- Relasi Ortu-Siswa
INSERT INTO ortu_siswa (ortu_id, siswa_id, hubungan) VALUES
(7, 1, 'Ayah'),
(8, 4, 'Ibu');

-- Mata Pelajaran
INSERT INTO mata_pelajaran (kode, nama, kelompok) VALUES
('PAI', 'Pendidikan Agama Islam', 'A'),
('PKN', 'Pendidikan Kewarganegaraan', 'A'),
('BIN', 'Bahasa Indonesia', 'A'),
('MTK', 'Matematika', 'A'),
('IPA', 'Ilmu Pengetahuan Alam', 'A'),
('IPS', 'Ilmu Pengetahuan Sosial', 'A'),
('SBK', 'Seni Budaya dan Keterampilan', 'B'),
('PJOK', 'Pendidikan Jasmani Olahraga', 'B'),
('BAR', 'Bahasa Arab', 'A'),
('BIG', 'Bahasa Inggris', 'A'),
('BTQ', 'Baca Tulis Quran', 'C'),
('PDM', 'Pendidikan Dasar Muatan Lokal', 'C');

-- Relasi Guru-Mapel-Kelas
INSERT INTO guru_mapel (guru_id, mapel_id, kelas_id, tahun_ajaran, semester) VALUES
(2, 1, 1, '2024/2025', 1), -- Guru1 -> PAI -> 1A
(2, 9, 1, '2024/2025', 1), -- Guru1 -> BAR -> 1A
(3, 4, 1, '2024/2025', 1), -- Guru2 -> MTK -> 1A
(3, 5, 1, '2024/2025', 1), -- Guru2 -> IPA -> 1A
(4, 3, 1, '2024/2025', 1), -- Guru3 -> BIN -> 1A
(4, 6, 1, '2024/2025', 1), -- Guru3 -> IPS -> 1A
(2, 1, 2, '2024/2025', 1), -- Guru1 -> PAI -> 2A
(3, 4, 2, '2024/2025', 1); -- Guru2 -> MTK -> 2A

-- Nilai contoh
INSERT INTO nilai (siswa_id, mapel_id, kelas_id, guru_id, tahun_ajaran, semester, nilai_harian, nilai_uts, nilai_uas, nilai_akhir, predikat, deskripsi) VALUES
(1, 1, 1, 2, '2024/2025', 1, 88, 85, 90, 88, 'A', 'Ananda sangat aktif dalam pembelajaran PAI'),
(1, 4, 1, 3, '2024/2025', 1, 75, 80, 78, 78, 'B+', 'Cukup baik dalam memahami konsep matematika'),
(1, 3, 1, 4, '2024/2025', 1, 82, 84, 86, 84, 'A-', 'Kemampuan membaca dan menulis sangat baik'),
(2, 1, 1, 2, '2024/2025', 1, 92, 90, 95, 92, 'A+', 'Sangat menonjol dalam hafalan dan ibadah'),
(2, 4, 1, 3, '2024/2025', 1, 88, 85, 90, 88, 'A', 'Menguasai operasi hitung dengan baik');

-- Kehadiran
INSERT INTO kehadiran (siswa_id, kelas_id, tahun_ajaran, semester, sakit, izin, alpa) VALUES
(1, 1, '2024/2025', 1, 2, 1, 0),
(2, 1, '2024/2025', 1, 0, 0, 0),
(3, 1, '2024/2025', 1, 3, 2, 1);
