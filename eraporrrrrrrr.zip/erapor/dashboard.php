<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
$user = getCurrentUser();
$db = getDB();

$pageTitle = 'Dashboard';

// ---- Stats per role ----
$stats = [];

if ($user['role'] === 'admin') {
    $stats['siswa']   = $db->query("SELECT COUNT(*) FROM siswa WHERE aktif=1")->fetchColumn();
    $stats['guru']    = $db->query("SELECT COUNT(*) FROM users WHERE role='guru' AND aktif=1")->fetchColumn();
    $stats['kelas']   = $db->query("SELECT COUNT(*) FROM kelas")->fetchColumn();
    $stats['mapel']   = $db->query("SELECT COUNT(*) FROM mata_pelajaran")->fetchColumn();
    $stats['nilai']   = $db->query("SELECT COUNT(*) FROM nilai WHERE tahun_ajaran='".TAHUN_AJARAN."' AND semester=".SEMESTER)->fetchColumn();
    $stats['wk']      = $db->query("SELECT COUNT(*) FROM users WHERE role='walikelas' AND aktif=1")->fetchColumn();

    // Nilai terbaru
    $recentNilai = $db->query("
        SELECT n.*, s.nama_lengkap as siswa_nama, m.nama as mapel_nama, u.nama_lengkap as guru_nama
        FROM nilai n
        JOIN siswa s ON n.siswa_id=s.id
        JOIN mata_pelajaran m ON n.mapel_id=m.id
        JOIN users u ON n.guru_id=u.id
        WHERE n.tahun_ajaran='".TAHUN_AJARAN."' AND n.semester=".SEMESTER."
        ORDER BY n.updated_at DESC LIMIT 8
    ")->fetchAll();

    // Rekap per kelas
    $rekapKelas = $db->query("
        SELECT k.nama_kelas, k.tahun_ajaran, COUNT(DISTINCT s.id) as jml_siswa,
               COUNT(DISTINCT n.id) as jml_nilai,
               ROUND(AVG(n.nilai_akhir),1) as rata_rata
        FROM kelas k
        LEFT JOIN siswa s ON s.kelas_id=k.id AND s.aktif=1
        LEFT JOIN nilai n ON n.kelas_id=k.id AND n.tahun_ajaran='".TAHUN_AJARAN."' AND n.semester=".SEMESTER."
        GROUP BY k.id ORDER BY k.tahun_ajaran DESC, k.tingkat
    ")->fetchAll();

} elseif ($user['role'] === 'guru') {
    // Mapel yang diajar
    $mapelDiajar = $db->prepare("
        SELECT gm.*, m.nama as mapel_nama, k.nama_kelas
        FROM guru_mapel gm
        JOIN mata_pelajaran m ON gm.mapel_id=m.id
        JOIN kelas k ON gm.kelas_id=k.id
        WHERE gm.guru_id=? AND gm.tahun_ajaran=? AND gm.semester=?
    ");
    $mapelDiajar->execute([$user['id'], TAHUN_AJARAN, SEMESTER]);
    $stats['mapel_list'] = $mapelDiajar->fetchAll();

    $stats['jml_mapel'] = count($stats['mapel_list']);
    $stmt = $db->prepare("SELECT COUNT(*) FROM nilai WHERE guru_id=? AND tahun_ajaran=? AND semester=?");
    $stmt->execute([$user['id'], TAHUN_AJARAN, SEMESTER]);
    $stats['jml_nilai'] = $stmt->fetchColumn();

    // Nilai terbaru guru ini
    $stmtRecent = $db->prepare("
        SELECT n.*, s.nama_lengkap as siswa_nama, m.nama as mapel_nama, k.nama_kelas
        FROM nilai n
        JOIN siswa s ON n.siswa_id=s.id
        JOIN mata_pelajaran m ON n.mapel_id=m.id
        JOIN kelas k ON n.kelas_id=k.id
        WHERE n.guru_id=? AND n.tahun_ajaran=? AND n.semester=?
        ORDER BY n.updated_at DESC LIMIT 6
    ");
    $stmtRecent->execute([$user['id'], TAHUN_AJARAN, SEMESTER]);
    $recentNilai = $stmtRecent->fetchAll();

} elseif ($user['role'] === 'walikelas') {
    $kelasList = getKelasWalikelas($user['id']);
    $kelas = $kelasList[0] ?? null;

    if ($kelas) {
        $stmtSiswa = $db->prepare("SELECT COUNT(*) FROM siswa WHERE kelas_id=? AND aktif=1");
        $stmtSiswa->execute([$kelas['id']]);
        $stats['jml_siswa'] = $stmtSiswa->fetchColumn();

        $stmtNilai = $db->prepare("SELECT COUNT(*) FROM nilai WHERE kelas_id=? AND tahun_ajaran=? AND semester=?");
        $stmtNilai->execute([$kelas['id'], TAHUN_AJARAN, SEMESTER]);
        $stats['jml_nilai'] = $stmtNilai->fetchColumn();

        $stmtAvg = $db->prepare("SELECT ROUND(AVG(nilai_akhir),1) FROM nilai WHERE kelas_id=? AND tahun_ajaran=? AND semester=?");
        $stmtAvg->execute([$kelas['id'], TAHUN_AJARAN, SEMESTER]);
        $stats['rata_nilai'] = $stmtAvg->fetchColumn() ?? 0;

        // Siswa terbaik
        $stmtTop = $db->prepare("
            SELECT s.nama_lengkap, ROUND(AVG(n.nilai_akhir),1) as rata
            FROM siswa s
            JOIN nilai n ON n.siswa_id=s.id
            WHERE n.kelas_id=? AND n.tahun_ajaran=? AND n.semester=?
            GROUP BY s.id ORDER BY rata DESC LIMIT 5
        ");
        $stmtTop->execute([$kelas['id'], TAHUN_AJARAN, SEMESTER]);
        $topSiswa = $stmtTop->fetchAll();
    }

} elseif ($user['role'] === 'ortu') {
    $stmtAnak = $db->prepare("
        SELECT s.*, k.nama_kelas
        FROM ortu_siswa os
        JOIN siswa s ON os.siswa_id=s.id
        LEFT JOIN kelas k ON s.kelas_id=k.id
        WHERE os.ortu_id=?
    ");
    $stmtAnak->execute([$user['id']]);
    $anakList = $stmtAnak->fetchAll();

    if (!empty($anakList)) {
        $anak = $anakList[0];
        $stmtNilai = $db->prepare("
            SELECT n.*, m.nama as mapel_nama
            FROM nilai n JOIN mata_pelajaran m ON n.mapel_id=m.id
            WHERE n.siswa_id=? AND n.tahun_ajaran=? AND n.semester=?
            ORDER BY m.nama
        ");
        $stmtNilai->execute([$anak['id'], TAHUN_AJARAN, SEMESTER]);
        $nilaiAnak = $stmtNilai->fetchAll();
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<?php if ($user['role'] === 'admin'): ?>
<!-- =================== ADMIN DASHBOARD =================== -->
<div class="stat-grid">
    <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-user-graduate"></i></div>
        <div>
            <div class="stat-value"><?= $stats['siswa'] ?></div>
            <div class="stat-label">Total Siswa Aktif</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-chalkboard-teacher"></i></div>
        <div>
            <div class="stat-value"><?= $stats['guru'] ?></div>
            <div class="stat-label">Guru</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon purple"><i class="fas fa-chalkboard"></i></div>
        <div>
            <div class="stat-value"><?= $stats['kelas'] ?></div>
            <div class="stat-label">Kelas Aktif</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon gold"><i class="fas fa-book"></i></div>
        <div>
            <div class="stat-value"><?= $stats['mapel'] ?></div>
            <div class="stat-label">Mata Pelajaran</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon orange"><i class="fas fa-star"></i></div>
        <div>
            <div class="stat-value"><?= $stats['nilai'] ?></div>
            <div class="stat-label">Data Nilai Diinput</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-user-tie"></i></div>
        <div>
            <div class="stat-value"><?= $stats['wk'] ?></div>
            <div class="stat-label">Wali Kelas</div>
        </div>
    </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;">
    <!-- Rekap Per Kelas -->
    <div class="card">
        <div class="card-header">
            <div class="card-title"><i class="fas fa-chart-bar"></i> Rekap Per Kelas</div>
        </div>
        <div class="table-responsive">
            <table>
                <thead><tr>
                    <th>Kelas</th><th>Siswa</th><th>Nilai Diinput</th><th>Rata-rata</th>
                </tr></thead>
                <tbody>
                <?php foreach ($rekapKelas as $rk): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($rk['nama_kelas']) ?></strong><?= $rk['tahun_ajaran'] !== TAHUN_AJARAN ? ' <small style="color:var(--text-muted);">('.$rk['tahun_ajaran'].')</small>' : '' ?></td>
                    <td><?= $rk['jml_siswa'] ?></td>
                    <td><?= $rk['jml_nilai'] ?></td>
                    <td>
                        <?php if ($rk['rata_rata']): ?>
                        <span class="badge badge-<?= $rk['rata_rata'] >= 75 ? 'success' : ($rk['rata_rata'] >= 60 ? 'warning' : 'danger') ?>">
                            <?= $rk['rata_rata'] ?>
                        </span>
                        <?php else: echo '<span class="text-muted">-</span>'; endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Nilai Terbaru -->
    <div class="card">
        <div class="card-header">
            <div class="card-title"><i class="fas fa-clock"></i> Nilai Terbaru</div>
        </div>
        <div class="table-responsive">
            <table>
                <thead><tr><th>Siswa</th><th>Mapel</th><th>Nilai</th></tr></thead>
                <tbody>
                <?php if (empty($recentNilai)): ?>
                <tr><td colspan="3" class="no-data"><i class="fas fa-inbox"></i> Belum ada nilai</td></tr>
                <?php else: ?>
                <?php foreach ($recentNilai as $n): ?>
                <tr>
                    <td><?= htmlspecialchars($n['siswa_nama']) ?></td>
                    <td><?= htmlspecialchars($n['mapel_nama']) ?></td>
                    <td><span class="pred pred-<?= substr($n['predikat'],0,1) ?>"><?= $n['nilai_akhir'] ?></span></td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php elseif ($user['role'] === 'guru'): ?>
<!-- =================== GURU DASHBOARD =================== -->
<div class="stat-grid">
    <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-book-open"></i></div>
        <div>
            <div class="stat-value"><?= $stats['jml_mapel'] ?></div>
            <div class="stat-label">Mapel Diampu</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-pen"></i></div>
        <div>
            <div class="stat-value"><?= $stats['jml_nilai'] ?></div>
            <div class="stat-label">Nilai Diinput</div>
        </div>
    </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;">
    <div class="card">
        <div class="card-header">
            <div class="card-title"><i class="fas fa-list"></i> Penugasan Mengajar</div>
            <a href="<?= APP_URL ?>/pages/guru/input_nilai.php" class="btn btn-primary btn-sm">
                <i class="fas fa-pen"></i> Input Nilai
            </a>
        </div>
        <div class="table-responsive">
            <table>
                <thead><tr><th>Mata Pelajaran</th><th>Kelas</th><th>Aksi</th></tr></thead>
                <tbody>
                <?php if (empty($stats['mapel_list'])): ?>
                <tr><td colspan="3" class="no-data"><i class="fas fa-inbox"></i> Belum ada penugasan</td></tr>
                <?php else: ?>
                <?php foreach ($stats['mapel_list'] as $m): ?>
                <tr>
                    <td><?= htmlspecialchars($m['mapel_nama']) ?></td>
                    <td><span class="badge badge-info"><?= htmlspecialchars($m['nama_kelas']) ?></span></td>
                    <td>
                        <a href="<?= APP_URL ?>/pages/guru/input_nilai.php?mapel_id=<?= $m['mapel_id'] ?>&kelas_id=<?= $m['kelas_id'] ?>" class="btn btn-primary btn-xs">
                            <i class="fas fa-pen"></i> Input
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="card-title"><i class="fas fa-clock"></i> Nilai Terbaru</div>
        </div>
        <div class="table-responsive">
            <table>
                <thead><tr><th>Siswa</th><th>Kelas</th><th>Mapel</th><th>Nilai</th></tr></thead>
                <tbody>
                <?php if (empty($recentNilai)): ?>
                <tr><td colspan="4" class="no-data"><i class="fas fa-inbox"></i> Belum ada nilai</td></tr>
                <?php else: ?>
                <?php foreach ($recentNilai as $n): ?>
                <tr>
                    <td><?= htmlspecialchars($n['siswa_nama']) ?></td>
                    <td><?= htmlspecialchars($n['nama_kelas']) ?></td>
                    <td><?= htmlspecialchars($n['mapel_nama']) ?></td>
                    <td><strong class="text-green"><?= $n['nilai_akhir'] ?></strong></td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php elseif ($user['role'] === 'walikelas'): ?>
<!-- =================== WALIKELAS DASHBOARD =================== -->
<?php if (!$kelas): ?>
<div class="card"><div class="card-body no-data">
    <i class="fas fa-exclamation-triangle" style="color:#f59e0b;"></i>
    <p>Anda belum ditugaskan sebagai wali kelas. Hubungi Admin.</p>
</div></div>
<?php else: ?>
<div class="stat-grid">
    <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-chalkboard"></i></div>
        <div>
            <div class="stat-value"><?= htmlspecialchars($kelas['nama_kelas']) ?></div>
            <div class="stat-label">Kelas Anda</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-users"></i></div>
        <div>
            <div class="stat-value"><?= $stats['jml_siswa'] ?></div>
            <div class="stat-label">Jumlah Siswa</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon gold"><i class="fas fa-star"></i></div>
        <div>
            <div class="stat-value"><?= $stats['jml_nilai'] ?></div>
            <div class="stat-label">Data Nilai</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon purple"><i class="fas fa-chart-line"></i></div>
        <div>
            <div class="stat-value"><?= $stats['rata_nilai'] ?: '-' ?></div>
            <div class="stat-label">Rata-rata Kelas</div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-trophy"></i> Siswa Berprestasi Kelas <?= htmlspecialchars($kelas['nama_kelas']) ?></div>
        <a href="<?= APP_URL ?>/pages/walikelas/rekap_nilai.php" class="btn btn-primary btn-sm">Rekap Lengkap</a>
    </div>
    <div class="table-responsive">
        <table>
            <thead><tr><th>No</th><th>Nama Siswa</th><th>Rata-rata</th><th>Peringkat</th></tr></thead>
            <tbody>
            <?php if (empty($topSiswa)): ?>
            <tr><td colspan="4" class="no-data"><i class="fas fa-inbox"></i> Belum ada data nilai</td></tr>
            <?php else: ?>
            <?php foreach ($topSiswa as $i => $ts): ?>
            <tr>
                <td><?= $i+1 ?></td>
                <td><?= htmlspecialchars($ts['nama_lengkap']) ?></td>
                <td><strong class="text-green"><?= $ts['rata'] ?></strong></td>
                <td>
                    <?php if ($i === 0): ?><span class="badge" style="background:#fef9c3;color:#a16207;">🥇 Terbaik</span>
                    <?php elseif ($i === 1): ?><span class="badge" style="background:#f0f0f0;color:#555;">🥈 2</span>
                    <?php elseif ($i === 2): ?><span class="badge" style="background:#fde8d8;color:#c2410c;">🥉 3</span>
                    <?php else: echo $i+1; endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php elseif ($user['role'] === 'ortu'): ?>
<!-- =================== ORTU DASHBOARD =================== -->
<?php if (empty($anakList)): ?>
<div class="card"><div class="card-body no-data">
    <i class="fas fa-user-slash" style="color:#f59e0b;font-size:48px;"></i>
    <p>Data anak Anda belum terhubung. Hubungi Admin sekolah.</p>
</div></div>
<?php else: ?>
<div class="stat-grid">
    <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-user-graduate"></i></div>
        <div>
            <div class="stat-value"><?= htmlspecialchars($anak['nama_lengkap']) ?></div>
            <div class="stat-label">Kelas <?= htmlspecialchars($anak['nama_kelas'] ?? '-') ?></div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon gold"><i class="fas fa-book"></i></div>
        <div>
            <div class="stat-value"><?= count($nilaiAnak) ?></div>
            <div class="stat-label">Mata Pelajaran Dinilai</div>
        </div>
    </div>
    <?php if (!empty($nilaiAnak)): ?>
    <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-chart-line"></i></div>
        <div>
            <div class="stat-value"><?= round(array_sum(array_column($nilaiAnak,'nilai_akhir')) / count($nilaiAnak), 1) ?></div>
            <div class="stat-label">Rata-rata Nilai</div>
        </div>
    </div>
    <?php endif; ?>
</div>

<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-star"></i> Nilai <?= htmlspecialchars($anak['nama_lengkap']) ?></div>
        <a href="<?= APP_URL ?>/pages/ortu/rapor_anak.php" class="btn btn-gold btn-sm"><i class="fas fa-file-pdf"></i> Lihat Rapor</a>
    </div>
    <div class="table-responsive">
        <table>
            <thead><tr><th>Mata Pelajaran</th><th>Harian</th><th>UTS</th><th>UAS</th><th>Nilai Akhir</th><th>Predikat</th></tr></thead>
            <tbody>
            <?php if (empty($nilaiAnak)): ?>
            <tr><td colspan="6" class="no-data"><i class="fas fa-inbox"></i> Belum ada nilai</td></tr>
            <?php else: ?>
            <?php foreach ($nilaiAnak as $n): ?>
            <tr>
                <td><?= htmlspecialchars($n['mapel_nama']) ?></td>
                <td><?= $n['nilai_harian'] ?></td>
                <td><?= $n['nilai_uts'] ?></td>
                <td><?= $n['nilai_uas'] ?></td>
                <td><strong class="text-green"><?= $n['nilai_akhir'] ?></strong></td>
                <td><span class="pred pred-<?= substr($n['predikat'],0,1) ?>"><?= $n['predikat'] ?></span></td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
